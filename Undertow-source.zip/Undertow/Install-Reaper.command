#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ "$(uname -s)" != Darwin ]]; then
  echo 'This installer is for macOS. On other systems copy Reaper/Undertow.jsfx into your REAPER resource Effects folder.'
  exit 1
fi
reaper_effects="$HOME/Library/Application Support/REAPER/Effects/NobodyButGhosts"
mkdir -p "$reaper_effects"
cp Reaper/Undertow.jsfx "$reaper_effects/Undertow.jsfx"
echo 'Installed Undertow for REAPER. Open the FX browser, press F5, and search Undertow.'
echo 'Portable/custom REAPER installs: use Options > Show REAPER resource path and copy the .jsfx into Effects.'
read -r -p 'Press Enter to close.'
