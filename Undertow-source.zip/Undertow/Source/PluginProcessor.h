#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "UndertowDSP.h"
#include "FactoryPresets.h"
class UndertowProcessor final : public juce::AudioProcessor {
public:
    UndertowProcessor();
    void prepareToPlay(double, int) override;
    void releaseResources() override {}
    void reset() override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "Undertow"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.25; }
    int getNumPrograms() override { return static_cast<int>(undertow::factoryPresets.size()); }
    int getCurrentProgram() override { return juce::jmax(0, selectedPreset.load()); }
    void setCurrentProgram(int) override;
    const juce::String getProgramName(int) override;
    int getSelectedPreset() const { return selectedPreset.load(); }
    bool isPresetModified() const;
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;
    juce::AudioProcessorValueTreeState state;
private:
    static juce::AudioProcessorValueTreeState::ParameterLayout layout();
    undertow::Parameters parameters() const;
    undertow::Engine engine;
    std::atomic<int> selectedPreset {-1};
    std::array<std::atomic<float>*, 6> values {};
    double activeSampleRate=48000;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(UndertowProcessor)
};
