#include "PluginProcessor.h"
#include "PluginEditor.h"
UndertowProcessor::UndertowProcessor()
    : AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true)
                                     .withOutput("Output",juce::AudioChannelSet::stereo(),true)),
      state(*this,nullptr,"UNDERTOW",layout()) {
    const char* ids[] = {"rate","depth","damp","lpg","mix","volume"};
    for (size_t i=0;i<values.size();++i) values[i]=state.getRawParameterValue(ids[i]);
}
juce::AudioProcessorValueTreeState::ParameterLayout UndertowProcessor::layout() {
    juce::AudioProcessorValueTreeState::ParameterLayout p;
    const char* ids[] = {"rate","depth","damp","lpg","mix"};
    const char* names[] = {"Rate","Depth","Damp","LPG","Mix"};
    const float defaults[] = {36,32,55,70,50};
    for(int i=0;i<5;++i)
        p.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{ids[i],1},names[i],
              juce::NormalisableRange<float>(0,100,0.1f),defaults[i],
              juce::AudioParameterFloatAttributes().withLabel("%")));
    p.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{"volume",1},"Volume",
          juce::NormalisableRange<float>(-24,12,0.1f),0,
          juce::AudioParameterFloatAttributes().withLabel("dB")));
    return p;
}
undertow::Parameters UndertowProcessor::parameters() const {
    return {values[0]->load()/100.0, values[1]->load()/100.0, values[2]->load()/100.0,
            values[3]->load()/100.0, values[4]->load()/100.0, values[5]->load()};
}
void UndertowProcessor::prepareToPlay(double sr,int) {
    activeSampleRate=sr; engine.setParameters(parameters(),true); engine.prepare(sr);
    setLatencySamples(0); // Wet delay is part of the effect; dry is immediate.
}
void UndertowProcessor::reset() { engine.setParameters(parameters(),true); engine.reset(); }
bool UndertowProcessor::isBusesLayoutSupported(const BusesLayout& b) const {
    return b.getMainInputChannelSet()==b.getMainOutputChannelSet()
        && (b.getMainOutputChannelSet()==juce::AudioChannelSet::mono()
            || b.getMainOutputChannelSet()==juce::AudioChannelSet::stereo());
}
void UndertowProcessor::processBlock(juce::AudioBuffer<float>& b,juce::MidiBuffer&) {
    juce::ScopedNoDenormals guard;
    for(int ch=getTotalNumInputChannels();ch<getTotalNumOutputChannels();++ch) b.clear(ch,0,b.getNumSamples());
    if(b.getNumChannels()<1) return;
    engine.setParameters(parameters());
    engine.process(b.getArrayOfWritePointers(),b.getNumChannels(),b.getNumSamples());
}
juce::AudioProcessorEditor* UndertowProcessor::createEditor() { return new UndertowEditor(*this); }
const juce::String UndertowProcessor::getProgramName(int n) {
    if(n<0 || n>=getNumPrograms()) return {};
    return undertow::factoryPresets[static_cast<size_t>(n)].name;
}
void UndertowProcessor::setCurrentProgram(int n) {
    if(n<0 || n>=getNumPrograms()) return;
    const char* ids[]={"rate","depth","damp","lpg","mix","volume"};
    const auto& preset=undertow::factoryPresets[static_cast<size_t>(n)];
    for(size_t i=0;i<6;++i) {
        auto* parameter=state.getParameter(ids[i]);
        parameter->beginChangeGesture();
        parameter->setValueNotifyingHost(parameter->convertTo0to1(preset.values[i]));
        parameter->endChangeGesture();
    }
    selectedPreset.store(n);
}
bool UndertowProcessor::isPresetModified() const {
    const int n=selectedPreset.load();
    if(n<0 || n>=static_cast<int>(undertow::factoryPresets.size())) return false;
    const auto& preset=undertow::factoryPresets[static_cast<size_t>(n)];
    for(size_t i=0;i<6;++i)
        if(std::abs(values[i]->load()-preset.values[i])>.051f) return true;
    return false;
}
void UndertowProcessor::getStateInformation(juce::MemoryBlock& b) {
    auto xml=state.copyState().createXml();
    xml->setAttribute("factoryPreset",selectedPreset.load());
    copyXmlToBinary(*xml,b);
}
void UndertowProcessor::setStateInformation(const void* data,int n) {
    if(auto xml=getXmlFromBinary(data,n))
        if(xml->hasTagName(state.state.getType())) {
            state.replaceState(juce::ValueTree::fromXml(*xml));
            const int n=xml->getIntAttribute("factoryPreset",-1);
            selectedPreset.store(n>=0 && n<getNumPrograms() ? n : -1);
        }
}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new UndertowProcessor(); }
