#pragma once
#include <array>
namespace undertow {
struct FactoryPreset { const char* name; std::array<float, 6> values; const char* description; };
// Rate, Depth, Damp, LPG, Mix in percent; Volume in dB.
inline constexpr std::array<FactoryPreset, 20> factoryPresets {{
    {"Ghost-lit chorus", {{36.0f, 32.0f, 55.0f, 70.0f, 50.0f, 0.0f}}, "Gentle chorus for clean chords."},
    {"Worn cassette", {{25.0f, 42.0f, 62.0f, 80.0f, 100.0f, 0.0f}}, "Slow softened tape drift."},
    {"Nervous reflection", {{75.0f, 45.0f, 20.0f, 85.0f, 60.0f, 0.0f}}, "Quick uneven movement with dry definition."},
    {"Dark undertow", {{18.0f, 30.0f, 72.0f, 25.0f, 75.0f, 0.0f}}, "Dark, restrained movement; input-sensitive sustain."},
    {"Indie shimmer", {{48.0f, 40.0f, 30.0f, 90.0f, 45.0f, 0.0f}}, "Brighter chorus for picked chords."},
    {"Post-punk glass", {{60.0f, 35.0f, 18.0f, 95.0f, 50.0f, 0.0f}}, "Fast crisp movement for rhythmic guitar."},
    {"New wave sway", {{52.0f, 55.0f, 25.0f, 85.0f, 50.0f, 0.0f}}, "More pronounced clean chorus."},
    {"Dream-pop veil", {{32.0f, 60.0f, 38.0f, 65.0f, 65.0f, 0.0f}}, "Softened drifting chords."},
    {"Ghost-lit lead", {{42.0f, 65.0f, 25.0f, 85.0f, 80.0f, 0.0f}}, "Pitch character for single-note melodies."},
    {"Bedroom tape", {{35.0f, 70.0f, 30.0f, 65.0f, 100.0f, 0.0f}}, "Audible uneven tape-style vibrato."},
    {"VHS night drive", {{55.0f, 80.0f, 22.0f, 75.0f, 100.0f, 0.0f}}, "Stronger restless pitch drift."},
    {"Warped reel", {{28.0f, 100.0f, 15.0f, 80.0f, 100.0f, 0.0f}}, "Slower events with deep pitch excursions."},
    {"Seasick cassette", {{70.0f, 100.0f, 10.0f, 80.0f, 100.0f, 0.0f}}, "Strong wobble based on the settings you liked."},
    {"Broken tracking", {{95.0f, 90.0f, 5.0f, 90.0f, 100.0f, -2.0f}}, "Rapid abrupt pitch transitions."},
    {"Nuclear suburbia", {{80.0f, 85.0f, 12.0f, 55.0f, 70.0f, -1.0f}}, "Dark busy chorus for unsettling parts."},
    {"Faded photograph", {{22.0f, 55.0f, 45.0f, 40.0f, 85.0f, 0.0f}}, "Muted tape color with gentle movement."},
    {"Drowned chords", {{38.0f, 65.0f, 25.0f, 20.0f, 100.0f, 0.0f}}, "Strong dark filtering; soft notes may choke."},
    {"Flickering light", {{65.0f, 60.0f, 15.0f, 35.0f, 90.0f, 0.0f}}, "Uneven pitch with input-sensitive filtering."},
    {"Bass shadow", {{30.0f, 35.0f, 30.0f, 75.0f, 30.0f, 0.0f}}, "Dry-forward starting point for bass."},
    {"Parallel haunting", {{85.0f, 100.0f, 8.0f, 90.0f, 25.0f, 0.0f}}, "Extreme movement blended behind the dry signal."},
}};
}
