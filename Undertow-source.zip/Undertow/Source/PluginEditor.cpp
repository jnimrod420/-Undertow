#include "PluginEditor.h"
namespace { const juce::Colour ink(0xff243b3d), paper(0xffe9e4d6), accent(0xffbf6846); }
UndertowLook::UndertowLook() {
    setColour(juce::Slider::textBoxTextColourId,ink);
    setColour(juce::Slider::textBoxBackgroundColourId,juce::Colours::transparentBlack);
    setColour(juce::Slider::textBoxOutlineColourId,juce::Colours::transparentBlack);
    setColour(juce::ComboBox::backgroundColourId,paper.darker(.06f));
    setColour(juce::ComboBox::textColourId,ink);
    setColour(juce::ComboBox::outlineColourId,ink.withAlpha(.25f));
    setColour(juce::PopupMenu::backgroundColourId,paper);
    setColour(juce::PopupMenu::textColourId,ink);
}
void UndertowLook::drawRotarySlider(juce::Graphics& g,int x,int y,int w,int h,float v,float start,float end,juce::Slider&) {
    auto box=juce::Rectangle<float>(static_cast<float>(x),static_cast<float>(y),static_cast<float>(w),static_cast<float>(h)).reduced(10);
    float radius=juce::jmin(box.getWidth(),box.getHeight())*.5f;
    auto c=box.getCentre(); float angle=start+v*(end-start);
    juce::Path track; track.addCentredArc(c.x,c.y,radius+4,radius+4,0,start,end,true);
    g.setColour(ink.withAlpha(.16f)); g.strokePath(track,juce::PathStrokeType(2));
    juce::Path active; active.addCentredArc(c.x,c.y,radius+4,radius+4,0,start,angle,true);
    g.setColour(accent); g.strokePath(active,juce::PathStrokeType(3));
    g.setColour(juce::Colours::black.withAlpha(.12f)); g.fillEllipse(c.x-radius,c.y-radius+3,radius*2,radius*2);
    g.setColour(ink); g.fillEllipse(c.x-radius,c.y-radius,radius*2,radius*2);
    g.setColour(juce::Colour(0xff3e5556)); g.drawEllipse(c.x-radius+3,c.y-radius+3,radius*2-6,radius*2-6,1);
    g.setColour(paper);
    g.drawLine(c.x+std::sin(angle)*radius*.35f,c.y-std::cos(angle)*radius*.35f,
               c.x+std::sin(angle)*radius*.80f,c.y-std::cos(angle)*radius*.80f,3);
}
UndertowEditor::UndertowEditor(UndertowProcessor& p):AudioProcessorEditor(p),processor(p) {
    setLookAndFeel(&look); setSize(660,480);
    const char* ids[]={"rate","depth","damp","lpg","mix","volume"};
    const char* names[]={"RATE","DEPTH","DAMP","LPG","MIX","VOLUME"};
    const char* help[]={"Speed of random pitch changes. Not tempo synced.","Amount of pitch wander.",
      "Higher settings soften and slow each random transition.","Higher settings open the filter and increase sustain. Responds to input level.",
      "0% dry; 50% chorus; 100% wandering vibrato.","Output level. 0 dB is nominal unity."};
    const double defaults[]={36,32,55,70,50,0};
    for(size_t i=0;i<6;++i) {
        auto& k=knobs[i]; addAndMakeVisible(k); k.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        k.setTextBoxStyle(juce::Slider::TextBoxBelow,false,92,22);
        k.setTextValueSuffix(i==5 ? " dB" : " %"); k.setDoubleClickReturnValue(true,defaults[i]); k.setTooltip(help[i]);
        auto& l=labels[i]; addAndMakeVisible(l); l.setText(names[i],juce::dontSendNotification);
        l.setJustificationType(juce::Justification::centred); l.setColour(juce::Label::textColourId,ink);
        attachments[i]=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.state,ids[i],k);
    }
    addAndMakeVisible(presets);
    presets.setTextWhenNothingSelected("Starting points");
    presets.addItem("Ghost-lit chorus",1); presets.addItem("Worn cassette",2);
    presets.addItem("Nervous reflection",3); presets.addItem("Dark undertow",4);
    presets.onChange=[this]{applyPreset(presets.getSelectedId()); presets.setSelectedId(0,juce::dontSendNotification);};
}
UndertowEditor::~UndertowEditor() { setLookAndFeel(nullptr); }
void UndertowEditor::applyPreset(int n) {
    if(n<1||n>4)return;
    static const float settings[][6]={{36,32,55,70,50,0},{25,42,62,80,100,0},{75,45,20,85,60,0},{18,30,72,25,75,0}};
    const char* ids[]={"rate","depth","damp","lpg","mix","volume"};
    for(int i=0;i<6;++i) {
        auto* p=processor.state.getParameter(ids[i]); p->beginChangeGesture();
        p->setValueNotifyingHost(p->convertTo0to1(settings[n-1][i])); p->endChangeGesture();
    }
}
void UndertowEditor::paint(juce::Graphics& g) {
    g.fillAll(paper);
    g.setColour(ink.withAlpha(.07f));
    for(int y=0;y<getHeight();y+=4)g.drawHorizontalLine(y,0,static_cast<float>(getWidth()));
    g.setColour(ink); g.setFont(juce::FontOptions(36.0f,juce::Font::bold));
    g.drawText("UNDERTOW",30,20,365,45,juce::Justification::centredLeft);
    g.setFont(juce::FontOptions(12.0f));
    g.drawText("RANDOM DRIFT / DYNAMIC LOW-PASS",32,64,360,20,juce::Justification::centredLeft);
    g.setColour(accent);g.drawLine(30,97,630,97,2);
    g.setColour(ink.withAlpha(.75f));g.setFont(juce::FontOptions(11.0f));
    g.drawText("NOBODY BUT GHOSTS   /   01",30,447,295,20,juce::Justification::centredLeft);
    g.drawText("MONO + LINKED STEREO",335,447,295,20,juce::Justification::centredRight);
}
void UndertowEditor::resized() {
    presets.setBounds(425,35,205,30);
    for(int i=0;i<6;++i) {
        int x=40+(i%3)*200, y=113+(i/3)*162;
        labels[static_cast<size_t>(i)].setBounds(x,y,180,24);
        knobs[static_cast<size_t>(i)].setBounds(x+20,y+25,140,130);
    }
}
