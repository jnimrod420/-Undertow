#pragma once
#include "PluginProcessor.h"
class UndertowLook final : public juce::LookAndFeel_V4 {
public:
    UndertowLook();
    void drawRotarySlider(juce::Graphics&,int,int,int,int,float,float,float,juce::Slider&) override;
};
class UndertowEditor final : public juce::AudioProcessorEditor {
public:
    explicit UndertowEditor(UndertowProcessor&);
    ~UndertowEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    UndertowProcessor& processor;
    UndertowLook look;
    std::array<juce::Slider,6> knobs;
    std::array<juce::Label,6> labels;
    std::array<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>,6> attachments;
    juce::ComboBox presets;
    juce::TooltipWindow tips {this, 700};
    void applyPreset(int);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(UndertowEditor)
};
