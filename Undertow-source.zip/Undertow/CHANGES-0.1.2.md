# Undertow 0.1.2

- Selected preset names remain visible and survive editor reopening and session recall.
- An asterisk marks edited presets. Older sessions without preset metadata show Custom settings and retain their knobs.
- All 20 presets are exposed as factory programs to compatible hosts.
- Fixed +3 dB wet-path makeup and up to +3 dB blend compensation raise effect output at 0 dB trim. Fully dry audio stays at unity. Dark LPG settings still reduce sustain intentionally.
- Existing sessions use the new gain curve and can sound louder; use Volume to adjust.
- Windows x64 VST3 and universal Intel/Apple Silicon macOS VST3 builds.

Factory presets are original starting points, not measured hardware matches. Native UI logic and actual VST3 loading are tested; REAPER itself is not available in the build environment.
