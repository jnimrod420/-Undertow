# Undertow 0.1.0

Six controls for uncertain pitch drift, dark chorus, worn-tape vibrato, and an input-responsive low-pass gate. Built for Nobody But Ghosts.

This is an original digital effect inspired by the publicly described behaviour of Fairfield Circuitry's Shallow Water. It is not an official Fairfield product, a circuit-exact clone, or a hardware-matched model. No proprietary firmware, schematics, branding, or artwork is included.

## Quick start: use it in REAPER on your Mac

**The included `.jsfx` is the version you can load without compiling.** REAPER compiles it automatically. It is a REAPER-native effect, not a VST3, and will not load in other DAWs.

1. Unzip this download on your Mac.
2. In REAPER choose **Options → Show REAPER resource path in finder**.
3. Open the **Effects** folder. Create a folder called **NobodyButGhosts** inside it.
4. Copy **Reaper/Undertow.jsfx** into that folder.
5. In the track FX browser press **F5** to refresh, then search **Undertow**. If needed, restart REAPER.
6. Start at the defaults. Use a recorded guitar DI or put it after your amp simulation. Keep playback volume low while finding the settings you like.

Alternatively, `Install-Reaper.command` copies it into the standard macOS REAPER resource folder. The manual method above also works with portable or custom REAPER installs.

Try an input peaking around −18 to −12 dBFS as a starting point. This is a suggested operating range, not a requirement. LPG responds to input level: a very quiet track may need gain before Undertow, while hot audio can keep the filter open. Volume changes the output, not the gate's sensitivity.

## Six controls

| Control | Behaviour |
| --- | --- |
| Rate | Changes the average frequency of random events, approximately 0.1–10 events/second; event spacing also varies randomly. |
| Depth | Amount of delay movement. Small settings give subtle wander; higher settings increase pitch changes. |
| Damp | Slows and softens each random transition. High Rate combined with high Damp reduces the movement that gets through. |
| LPG | Higher values open the envelope-responsive low-pass filter and gate, increasing brightness and sustain. Lower values darken and shorten notes. |
| Mix | 0% is dry, 50% gives chorus, and 100% gives wandering vibrato. |
| Volume | −24 to +12 dB output gain. 0 dB is nominal unity; filtering and saturation can reduce the perceived wet level. |

The dry path has no added delay. The wet path has approximately 15–25 ms of intentional effect delay. No host compensation is requested. Stereo channels share modulation and envelope detection; they retain separate audio paths. There is no feedback, generated hiss, oversampling switch, or tempo sync in this first version.

### Starting points

Enter these values in the JSFX sliders. The VST3/AU editor includes the same starting points in its menu. Save your own presets using REAPER's preset menu.

| Sound | Rate | Depth | Damp | LPG | Mix | Volume |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Ghost-lit chorus | 36 | 32 | 55 | 70 | 50 | 0 dB |
| Worn cassette | 25 | 42 | 62 | 80 | 100 | 0 dB |
| Nervous reflection | 75 | 45 | 20 | 85 | 60 | 0 dB |
| Dark undertow | 18 | 30 | 72 | 25 | 75 | 0 dB |

For your post-punk guitar parts, start with Ghost-lit chorus after the amp. For a more obvious broken-tape effect on synths, try Worn cassette.

## Build the macOS VST3 and AU

**No compiled macOS `.vst3` or `.component` is included.** The supplied source and build script target both Apple Silicon and Intel Macs on macOS 11 or later. The Mac build and DAW loading must still be verified on a Mac.

You need:

- Apple's Command Line Tools: open Terminal and run `xcode-select --install`, then finish Apple's installation dialog.
- CMake 3.22 or newer: install from https://cmake.org/download/ and put `CMake.app` in Applications, or use an existing CMake installation.
- Internet access for the first build to fetch the pinned JUCE 8.0.6 source archive.

Open `Build-Mac.command`, or in Terminal change into this extracted folder and run:

```bash
bash Build-Mac.command
```

Allow several minutes for the first build. The script builds a universal VST3 and AU, runs the DSP tests, applies a local ad-hoc signature, and installs them in:

- `~/Library/Audio/Plug-Ins/VST3/Undertow.vst3`
- `~/Library/Audio/Plug-Ins/Components/Undertow.component`

Build products also remain in `build-mac/Undertow_artefacts/Release/`. The script replaces existing Undertow bundles at those paths. These are local development builds, not Apple-notarized distribution installers. If macOS prevents opening a downloaded command file, use the Terminal command above.

In REAPER, open **Preferences → Plug-ins → VST**, rescan, and search **Undertow**. For AU, restart REAPER if the effect does not appear. VST3 and AU expose six automatable parameters and save settings with the host project. Double-click a knob to restore its default value.

An optional `.github/workflows/build-mac.yml` also builds both formats on a Mac GitHub Actions runner. To use it, put the contents of this folder at your repository root and run **Build Mac plugins**. Nothing has been uploaded to GitHub or published on your behalf.

## Validation and limits

See `VALIDATION.md` for the checks actually run. Audio-engine tests and EEL compilation/parity tests do not replace Mac host tests or hardware listening comparisons. This is a first implementation for auditioning and refinement.

For framework-free C++ engine tests:

```bash
cmake -S . -B build-tests -DUNDERTOW_DSP_ONLY=ON
cmake --build build-tests
ctest --test-dir build-tests --output-on-failure
```

## Dependencies and source references

- JUCE 8.0.6 is downloaded at build time with a pinned SHA-256. Its separate JUCE licensing applies: https://juce.com/legal/juce-8-licence/
- Original project files are provided under `LICENSE`. That license does not change the licensing of JUCE or any bundled dependency JUCE supplies.
- Fairfield's official specification describes the behavioural reference: https://cdn.shopify.com/s/files/1/0234/8231/files/KFM-specs.pdf
- REAPER's JSFX reference: https://www.reaper.fm/sdk/js/js.php
