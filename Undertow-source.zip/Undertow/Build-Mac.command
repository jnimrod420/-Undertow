#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ "$(uname -s)" != Darwin ]]; then echo 'Run this on a Mac.'; exit 1; fi
if ! xcrun --find clang >/dev/null 2>&1; then
  echo 'Install Apple Command Line Tools by running xcode-select --install in Terminal, then rerun.'; exit 1
fi
cmake_bin="$(command -v cmake || true)"
if [[ -z "$cmake_bin" && -x /Applications/CMake.app/Contents/bin/cmake ]]; then
  cmake_bin=/Applications/CMake.app/Contents/bin/cmake
fi
if [[ -z "$cmake_bin" ]]; then
  echo 'Install CMake from https://cmake.org/download/ (put CMake.app in Applications), then rerun.'; exit 1
fi
"$cmake_bin" -S . -B build-mac -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_ARCHITECTURES='arm64;x86_64' -DCMAKE_OSX_DEPLOYMENT_TARGET=11.0
"$cmake_bin" --build build-mac --config Release --target Undertow_VST3 Undertow_AU undertow_tests --parallel 2
"$cmake_bin" --build build-mac --target test
plugin_dir=build-mac/Undertow_artefacts/Release
for plugin in "$plugin_dir/VST3/Undertow.vst3" "$plugin_dir/AU/Undertow.component"; do
  /usr/bin/codesign --force --deep --sign - "$plugin"
  /usr/bin/codesign --verify --deep --strict "$plugin"
done
mkdir -p "$HOME/Library/Audio/Plug-Ins/VST3" "$HOME/Library/Audio/Plug-Ins/Components"
/usr/bin/ditto "$plugin_dir/VST3/Undertow.vst3" "$HOME/Library/Audio/Plug-Ins/VST3/Undertow.vst3"
/usr/bin/ditto "$plugin_dir/AU/Undertow.component" "$HOME/Library/Audio/Plug-Ins/Components/Undertow.component"
echo 'Built and installed Undertow VST3 + AU (Apple Silicon and Intel). Rescan plugins in REAPER.'
read -r -p 'Press Enter to close.'
