# Validation — 2026-10-12

## Checks completed

- Built the independent C++17 audio engine and test executables with GCC 13.3 on Linux.
- CTest passed: sample-exact dry output at unity; silent input gives silent output; mono processing; identical stereo channels stay identical; extreme Rate/Depth/Damp/LPG combinations; rapid parameter changes; finite bounded output at 8, 44.1, 48, 96, 192, and 384 kHz; deterministic restarts; Depth changes the output; LPG increases openness; block partition invariance; DC rejection; reset clears audio history; non-finite control-value fallback.
- Compiled both JUCE processor/editor translation units against JUCE 8.0.6 with C++ syntax checks.
- Compiled and executed the actual JSFX sections using Cockos WDL's portable EEL engine. Compared output snapshots with the C++ engine for five cases, including dry output, high output gain, and extreme controls.

| Sample rate | Knobs: Rate / Depth / Damp / LPG / Mix / Volume | Maximum snapshot difference |
| --- | --- | ---: |
| 44.1 kHz | 36 / 32 / 55 / 70 / 50 / 0 dB | 0.000000012 |
| 48 kHz | 36 / 32 / 55 / 70 / 50 / 0 dB | 0.000000009 |
| 96 kHz | 75 / 100 / 0 / 100 / 100 / +12 dB | 0.000000036 |
| 192 kHz | 0 / 0 / 100 / 0 / 100 / −24 dB | 0.000000001 |
| 48 kHz | 100 / 100 / 100 / 100 / 0 / 0 dB | 0.000000003 |

Stereo difference was zero in those JSFX checks. Float-versus-double rounding accounts for the tiny implementation differences. Tests/check_jsfx.py and Tests/JSFXReference.cpp reproduce these comparisons with a local WDL loose_eel executable.

- AddressSanitizer and UndefinedBehaviorSanitizer passed the C++ engine checks. LeakSanitizer was disabled because process inspection is unavailable in this environment; no leak-test result is claimed.
- Bash syntax checks passed for both Mac command scripts.

## Outstanding validation

- macOS universal VST3/AU compilation, local signing, installation, host scan, editor rendering, automation gestures, and session recall have not been exercised on a Mac.
- The JSFX has been tested in EEL, but not loaded into a running REAPER session here.
- No comparison recordings from the physical pedal were supplied. Numerical correctness does not establish sonic equivalence with the hardware. Delay range, filter mapping, gate response, and saturation are original approximations that can be refined after listening.
- No claim of notarization, distribution-ready binaries, circuit accuracy, or exact hardware knob calibration is made.
