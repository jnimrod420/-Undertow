# Undertow: 20 factory presets

These are original starting points for Undertow, not measured matches to the Shallow Water demo at 3:21. Select them from the plugin’s Starting points menu after rebuilding. Knob edits and session recall continue to use the existing parameter state.

The first four presets retain their original settings. Most stronger presets use lower Damp because high Damp suppresses pitch movement. LPG depends on input level; dark presets can shorten sustain. Volumes are starting values, not loudness-matched.

| Preset | Rate | Depth | Damp | LPG | Mix | Volume dB | Intended use |
|---|---:|---:|---:|---:|---:|---:|---|
| Ghost-lit chorus | 36 | 32 | 55 | 70 | 50 | 0 | Gentle chorus for clean chords. |
| Worn cassette | 25 | 42 | 62 | 80 | 100 | 0 | Slow softened tape drift. |
| Nervous reflection | 75 | 45 | 20 | 85 | 60 | 0 | Quick uneven movement with dry definition. |
| Dark undertow | 18 | 30 | 72 | 25 | 75 | 0 | Dark, restrained movement; input-sensitive sustain. |
| Indie shimmer | 48 | 40 | 30 | 90 | 45 | 0 | Brighter chorus for picked chords. |
| Post-punk glass | 60 | 35 | 18 | 95 | 50 | 0 | Fast crisp movement for rhythmic guitar. |
| New wave sway | 52 | 55 | 25 | 85 | 50 | 0 | More pronounced clean chorus. |
| Dream-pop veil | 32 | 60 | 38 | 65 | 65 | 0 | Softened drifting chords. |
| Ghost-lit lead | 42 | 65 | 25 | 85 | 80 | 0 | Pitch character for single-note melodies. |
| Bedroom tape | 35 | 70 | 30 | 65 | 100 | 0 | Audible uneven tape-style vibrato. |
| VHS night drive | 55 | 80 | 22 | 75 | 100 | 0 | Stronger restless pitch drift. |
| Warped reel | 28 | 100 | 15 | 80 | 100 | 0 | Slower events with deep pitch excursions. |
| Seasick cassette | 70 | 100 | 10 | 80 | 100 | 0 | Strong wobble based on the settings you liked. |
| Broken tracking | 95 | 90 | 5 | 90 | 100 | -2 | Rapid abrupt pitch transitions. |
| Nuclear suburbia | 80 | 85 | 12 | 55 | 70 | -1 | Dark busy chorus for unsettling parts. |
| Faded photograph | 22 | 55 | 45 | 40 | 85 | 0 | Muted tape color with gentle movement. |
| Drowned chords | 38 | 65 | 25 | 20 | 100 | 0 | Strong dark filtering; soft notes may choke. |
| Flickering light | 65 | 60 | 15 | 35 | 90 | 0 | Uneven pitch with input-sensitive filtering. |
| Bass shadow | 30 | 35 | 30 | 75 | 30 | 0 | Dry-forward starting point for bass. |
| Parallel haunting | 85 | 100 | 8 | 90 | 25 | 0 | Extreme movement blended behind the dry signal. |

## Build

This package contains updated source, not a newly compiled Mac VST3. Replace the project with the included Undertow directory and run its Build-Mac.command on a Mac with Xcode tools, or upload this source to the existing GitHub build workflow. The plugin identity and six parameters are unchanged. FactoryPresets.h is the single bank used by the editor and DSP checks.
