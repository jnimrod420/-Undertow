#!/usr/bin/env python3
"""Compare actual JSFX EEL with C++ samples. Requires WDL loose_eel and reference executable.
python3 Tests/check_jsfx.py /path/to/WDL/WDL/eel2/loose_eel /path/to/undertow_reference
"""
import math
import subprocess
import sys
import tempfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]
s = (root / 'Reaper/Undertow.jsfx').read_text()
init = s.split('@init\n')[1].split('@slider\n')[0]
slider = s.split('@slider\n')[1].split('@sample\n')[0]
sample = s.split('@sample\n')[1]
cases = [(44100,[36,32,55,70,50,0]), (48000,[36,32,55,70,50,0]),
         (96000,[75,100,0,100,100,12]), (192000,[0,0,100,0,100,-24]),
         (48000,[100,100,100,100,0,0])]
for sr, knobs in cases:
    setup = f'srate={sr};' + ''.join(f'slider{i+1}={x};' for i,x in enumerate(knobs))
    code = setup + '\n' + init + slider + '\nfunction sampleStep() (\n' + sample + '\n);\n'
    code += '''i=0;sum=0;err=0;
loop(srate,
 spl0=spl1=0.2*sin(2*$pi*440*i/srate);sampleStep();
 err=max(err,abs(spl0-spl1));sum+=spl0*spl0;
 i%1000==0 ? printf("%.9f\\n",spl0);i+=1;
);
printf("RMS=%.9f stereo_error=%.9f\\n",sqrt(sum/srate),err);
'''
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / 'test.eel';path.write_text(code)
        eel = subprocess.run([sys.argv[1],str(path)],check=True,capture_output=True,text=True)
        if eel.stderr.strip():raise RuntimeError(eel.stderr)
        cpp = subprocess.check_output([sys.argv[2],str(sr),*map(str,knobs)],text=True)
    a,b=cpp.splitlines(),eel.stdout.splitlines()
    assert len(a)==len(b), (len(a),len(b))
    error = max(abs(float(x)-float(y)) for x,y in zip(a[:-1],b[:-1]))
    assert math.isfinite(error) and error < 2e-6, (sr,error)
    assert 'stereo_error=0.000000000' in b[-1]
    print(f'PASS {sr} Hz: maximum sample snapshot difference {error:.3g}')
