#include "UndertowDSP.h"
#include "FactoryPresets.h"
#include <iostream>
#include <limits>
#include <stdexcept>
#include <cstdlib>
using undertow::Engine; using undertow::Parameters;
void require(bool yes,const char* message) { if(!yes)throw std::runtime_error(message); }
std::vector<float> render(Parameters p,double sr,int channels=2,bool automate=false) {
    Engine e; e.setParameters(p,true); e.prepare(sr);
    int n=static_cast<int>(sr*1.5); std::vector<float> left(n),right(n);
    for(int i=0;i<n;++i) left[i]=right[i]=static_cast<float>(.2*std::sin(6.283185307179586*440*i/sr));
    for(int i=0;i<n;) {
        int count=std::min(127,n-i);
        if(automate) { p.rate=(i%500)/500.0; p.depth=1-p.rate; p.damp=p.rate; p.lpg=1-p.rate; p.mix=p.rate; e.setParameters(p); }
        float* ptr[]={left.data()+i,right.data()+i}; e.process(ptr,channels,count); i+=count;
    }
    for(int i=0;i<n;++i) {
        require(std::isfinite(left[i])&&std::abs(left[i])<2,"unstable output");
        if(channels==2)require(left[i]==right[i],"stereo linking broken");
    }
    return left;
}
double rms(const std::vector<float>& x,size_t offset=0) {
    double sum=0; for(size_t i=offset;i<x.size();++i)sum+=x[i]*x[i]; return std::sqrt(sum/(x.size()-offset));
}
int main() {
 try {
    for(double sr:{8000.,44100.,48000.,96000.,192000.,384000.}) {
        Parameters p; p.mix=0; auto dry=render(p,sr);
        for(size_t i=0;i<dry.size();++i)
            require(dry[i]==static_cast<float>(.2*std::sin(6.283185307179586*440*i/sr)),"dry not sample exact");
        for(int mode=0;mode<8;++mode) {
            p={mode&1?1.:0.,mode&2?1.:0.,mode&4?1.:0.,mode&1?0.:1.,1.,12.}; render(p,sr);
        }
        render({},sr,1,true); render({},sr,2,true);
        Engine e; e.prepare(sr); std::vector<float> zero(2048); float* ptr[]={zero.data()};
        e.process(ptr,1,2048); require(rms(zero)==0,"silence produces signal");
    }
    for (const auto& preset : undertow::factoryPresets) {
        const auto& v=preset.values;
        Parameters factory {v[0]/100.,v[1]/100.,v[2]/100.,v[3]/100.,v[4]/100.,v[5]};
        for(double sr:{44100.,48000.,96000.}) {
            render(factory,sr,1); render(factory,sr,2);
        }
    }
    Parameters p; p.mix=1; p.depth=0; auto still=render(p,48000);
    p.depth=1; auto moving=render(p,48000);
    require(still!=moving,"depth has no effect");
    require(moving==render(p,48000),"render not deterministic");
    p.lpg=0; auto dark=render(p,48000); p.lpg=1; auto open=render(p,48000);
    require(rms(open,10000)>rms(dark,10000)*1.3,"LPG does not open");
    // Block partition invariance: RNG and smoothers advance per sample, not per block.
    Engine a,b; a.prepare(48000);b.prepare(48000);
    std::vector<float> x(96000),y;
    for(size_t i=0;i<x.size();++i)x[i]=static_cast<float>(.2*std::sin(.03*i)); y=x;
    float* xp[]={x.data()};a.process(xp,1,static_cast<int>(x.size()));
    for(int i=0;i<96000;i+=64){float* yp[]={y.data()+i};b.process(yp,1,64);}
    require(x==y,"block-size dependent output");
    // DC settles, and reprepare/reset clears stored audio.
    Engine dc; dc.prepare(48000); std::vector<float> constant(240000,.2f); float* cp[]={constant.data()};
    p={};p.mix=1;p.depth=0;dc.setParameters(p,true);dc.process(cp,1,240000);
    require(rms(constant,200000)<1e-6,"DC blocker failed");
    dc.reset();std::vector<float> silence(10000);float* sp[]={silence.data()};dc.process(sp,1,10000);
    require(rms(silence)==0,"reset leaks old audio");
    Parameters invalid;invalid.rate=std::numeric_limits<double>::quiet_NaN();invalid.volumeDb=std::numeric_limits<double>::infinity();
    render(invalid,48000);
    std::cout<<"PASS: sample-exact dry, silence, reset, DC, mono/stereo, automation, parameter extremes,\n"
             <<"      six sample rates, determinism, LPG response, modulation, block invariance.\n";
    return EXIT_SUCCESS;
 } catch(const std::exception& e) {std::cerr<<"FAIL: "<<e.what()<<'\n';return EXIT_FAILURE;}
}
