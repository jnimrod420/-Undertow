#include "PluginProcessor.h"
#include <iostream>
#include <stdexcept>
void require(bool ok,const char* message) { if(!ok) throw std::runtime_error(message); }
juce::ComboBox* findMenu(juce::AudioProcessorEditor& editor) {
    for(int i=0;i<editor.getNumChildComponents();++i)
        if(auto* menu=dynamic_cast<juce::ComboBox*>(editor.getChildComponent(i))) return menu;
    throw std::runtime_error("Preset menu missing");
}
int main() {
    juce::ScopedJuceInitialiser_GUI init;
    try {
        UndertowProcessor processor;
        require(processor.getNumPrograms()==20,"Factory program count");
        const char* ids[]={"rate","depth","damp","lpg","mix","volume"};
        for(int n=0;n<20;++n) {
            processor.setCurrentProgram(n);
            require(processor.getSelectedPreset()==n,"Preset selection lost");
            require(!processor.isPresetModified(),"Fresh preset marked edited");
            for(size_t i=0;i<6;++i)
                require(std::abs(processor.state.getRawParameterValue(ids[i])->load()-undertow::factoryPresets[static_cast<size_t>(n)].values[i])<.051f,"Preset value wrong");
            std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
            auto* menu=findMenu(*editor);
            require(menu->getNumItems()==20,"Menu entries missing");
            require(menu->getText()==processor.getProgramName(n),"Selected name not visible");
        }
        processor.setCurrentProgram(12);
        auto* depth=processor.state.getParameter("depth");
        depth->setValueNotifyingHost(.81f);
        require(processor.isPresetModified(),"Edited marker missing");
        juce::MemoryBlock saved; processor.getStateInformation(saved);
        processor.setCurrentProgram(0);
        processor.setStateInformation(saved.getData(),static_cast<int>(saved.getSize()));
        require(processor.getSelectedPreset()==12,"Session lost preset identity");
        require(std::abs(depth->getValue()-.81f)<.0001f,"Session lost edited knob");
        {
            std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
            require(findMenu(*editor)->getText()=="Seasick cassette *","Reopened editor label wrong");
        }
        // Old sessions have no preset metadata; preserve knobs and show Custom settings.
        auto legacy=processor.state.copyState().createXml(); legacy->removeAttribute("factoryPreset");
        juce::MemoryBlock old; juce::AudioProcessor::copyXmlToBinary(*legacy,old);
        processor.setStateInformation(old.getData(),static_cast<int>(old.getSize()));
        require(processor.getSelectedPreset()==-1,"Legacy session preset falsely identified");
        std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
        require(findMenu(*editor)->getText()=="Custom settings","Custom session label wrong");
        std::cout<<"PASS: 20 factory programs, all knob values, visible menu names, edited marker, preset and knob session recall, editor reopen, legacy sessions.\n";
        return 0;
    } catch(const std::exception& e) {std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}
}
