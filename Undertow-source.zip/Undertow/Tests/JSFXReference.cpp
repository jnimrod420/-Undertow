#include "UndertowDSP.h"
#include <cstdio>
#include <cstdlib>
int main(int argc,char** argv) {
    double sr=argc>1?std::atof(argv[1]):48000;
    undertow::Parameters p;
    if(argc>7)p={std::atof(argv[2])/100,std::atof(argv[3])/100,std::atof(argv[4])/100,
                 std::atof(argv[5])/100,std::atof(argv[6])/100,std::atof(argv[7])};
    undertow::Engine e;e.setParameters(p,true);e.prepare(sr);
    float l=0,r=0;float* data[]={&l,&r};double sum=0;
    int count=static_cast<int>(sr);
    for(int i=0;i<count;++i){
        l=r=static_cast<float>(.2*std::sin(2*3.14159265358979323846*440*i/sr));
        e.process(data,2,1);sum+=l*l;
        if(i%1000==0)std::printf("%.9f\n",l);
    }
    std::printf("RMS=%.9f stereo_error=%.9f\n",std::sqrt(sum/count),0.0);
}
