#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p "$HOME/Library/Audio/Plug-Ins/VST3" "$HOME/Library/Audio/Plug-Ins/Components"
ditto "Night Mass.vst3" "$HOME/Library/Audio/Plug-Ins/VST3/Night Mass.vst3"
ditto "Night Mass.component" "$HOME/Library/Audio/Plug-Ins/Components/Night Mass.component"
xattr -dr com.apple.quarantine "$HOME/Library/Audio/Plug-Ins/VST3/Night Mass.vst3" "$HOME/Library/Audio/Plug-Ins/Components/Night Mass.component" 2>/dev/null || true
printf 'Night Mass installed. Restart your DAW and rescan plugins.\n'
