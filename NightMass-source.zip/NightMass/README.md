# Night Mass 1.0.0
Nobody But Ghosts — post-punk / darkwave multi-effects.

Original implementation inspired by the general multi-effect workflow of Prod Kult's Monolyth. It does not use Prod Kult code, samples, artwork or factory presets, and is not an exact sonic emulation.

## Included
- Eight independently bypassable effects, reorderable with each module's < and > buttons.
- Grip: linked slow/fast compressor.
- Bite: warm/hot drive with source-sensitive input filtering and cabinet tone.
- Veil: resonant low-pass, high-pass or band-pass filter.
- Fracture: fuzz or digital bit/sample-rate erosion.
- Wander: stereo chorus, vibrato or flange.
- Echoes: tape, clean or ping-pong delay.
- Crypt: chamber/hall feedback-network reverb.
- Pulse: rhythmic volume swells or chopped gates.
- 50 original factory presets, ten per source mode: guitar, bass, drums, synth and vocals.
- Conjure: generate a new patch based on the current source.
- Presence: dry/wet blend. Voice: output trim. Global bypass passes dry input unchanged.
- Host tempo sync and a fallback BPM control; disable sync for free-running delay/pulse.
- Mono/stereo support, host automation and session recall, including chain order.
- Worn silver interface, typewriter lettering, black knobs, fanged pixel ghosts and dried blood splatter.

Each effect has three live knobs and a mode selector. The third knob is its blend (Pulse: depth). Effect numbers show processing order. Source modes change the preamp's input voicing; the ten presets for each source tune the whole rack. Changing source alone preserves the current rack settings.

Delay sync divisions, lowest to highest Time position: 1/16, 1/8, dotted 1/8, 1/4, dotted 1/4, 1/2. Pulse sync divisions are two beats, one beat, half a beat. Transport beat position aligns Pulse when supplied by the host.

The preset menu marks edited presets with *. Generated patches say Unholy transmission. Custom settings are saved in DAW sessions; this version does not include a separate user-preset file browser.

## Downloads / installation
This archive contains the source project. Compiled Mac and Windows downloads are packaged separately.

When packaged: macOS 11+ universal Intel/Apple Silicon VST3 and AU; Windows 10/11 x64 VST3 with Inno Setup installer.

Mac: unzip the Mac package and run Install-Mac.command. If macOS blocks an unsigned download, use Finder's Open command / Privacy & Security as appropriate. The script installs to your user audio-plugin folders. It clears quarantine only on these two installed plugin bundles. Plugins receive ad-hoc signatures, not Apple notarization.

Windows: run NightMass-1.0.0-Windows-Setup.exe; it installs the complete bundle to Common Files/VST3 and supplies an uninstaller. Close your DAW before installation. Windows installer signing is not configured.

Restart your DAW and rescan plugins. In REAPER select Night Mass from the VST3 effects list. AU is also provided for compatible Mac hosts.

## Build
CMake 3.22+, C++17 compiler, internet access to fetch JUCE 8.0.12, and platform SDKs are required.

macOS:
```
cmake -S NightMass -B build-nightmass -DCMAKE_BUILD_TYPE=Release "-DCMAKE_OSX_ARCHITECTURES=arm64;x86_64" -DCMAKE_OSX_DEPLOYMENT_TARGET=11.0
cmake --build build-nightmass --config Release --parallel 3
ctest --test-dir build-nightmass -C Release --output-on-failure
```
Windows (Visual Studio 2022 developer environment):
```
cmake -S NightMass -B build-nightmass -A x64
cmake --build build-nightmass --config Release --parallel 3
ctest --test-dir build-nightmass -C Release --output-on-failure
```

Repository workflow: .github/workflows/build-night-mass.yml. The packaged copy inside NightMass/.github/workflows is a reference; place it at repository root for GitHub Actions. Native CI runs audio tests, editor/state checks, actual VST3 loading, Mac universal verification, and Windows install/hash/load/uninstall tests before publishing artifacts.

JUCE is a separate dependency; obey its license for any distribution. No third-party dependency source is included here.
