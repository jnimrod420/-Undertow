#include "../Source/Presets.h"
#include <iostream>
#include <stdexcept>
#include <set>
#include <sstream>
void require(bool ok,const char* text){if(!ok)throw std::runtime_error(text);}
int main(){try{
 std::set<std::string> names;for(const auto& p:nightmass::factoryPresets){require(names.insert(p.name).second,"Duplicate preset name");std::set<int> order(p.settings.order.begin(),p.settings.order.end());require(order.size()==8,"Invalid chain order");}
 std::set<long long> signatures;
 for(double sr:{44100.,48000.,96000.,192000.})for(int channels:{1,2})for(const auto& preset:nightmass::factoryPresets){nightmass::Engine e;e.prepare(sr);auto s=preset.settings;float l[127],r[127];float* ptr[]={l,r};double energy=0;for(int block=0;block<25;++block){for(int i=0;i<127;++i){l[i]=float(.3*std::sin((block*127+i)*.057)+.08*std::sin((block*127+i)*.19));r[i]=float(.2*std::sin((block*127+i)*.093));}e.process(ptr,channels,127,s);for(int i=0;i<127;++i){require(std::isfinite(l[i])&&std::abs(l[i])<8,"Invalid preset output");require(std::isfinite(r[i]),"Invalid stereo output");energy+=l[i]*l[i];}}require(energy>0.0001,"Silent preset");if(sr==48000&&channels==2)signatures.insert(std::llround(energy*1e8));}
 require(signatures.size()==50,"Presets not audibly distinct on reference signal");
 for(int count:{1,2}){nightmass::Engine e;e.prepare(48000);nightmass::Settings s;float l[256],r[256];float* ptr[]={l,r};s.mix=0;for(int i=0;i<256;++i)l[i]=r[i]=float(.4*std::sin(i*.1));e.process(ptr,count,256,s);for(int i=0;i<256;++i)require(std::abs(l[i]-.4*std::sin(i*.1))<1e-7,"Dry mix must be unity");s.bypass=true;s.mix=1;s.output=12;for(int i=0;i<256;++i)l[i]=r[i]=.123f;e.process(ptr,count,256,s);for(auto x:l)require(x==.123f,"Bypass must be unity");}
 // Stress every engine mode, parameter extreme, reordered chain and changing sample block size.
 for(int mode=0;mode<3;++mode){nightmass::Engine e;e.prepare(48000);auto s=nightmass::factoryPresets[0].settings;float l[256],r[256];float* ptr[]={l,r};for(auto& m:s.modules){m.on=true;m.mode=mode;m.v={{1,1,1}};}s.order={{7,6,5,4,3,2,1,0}};for(int b=0;b<800;++b){for(int i=0;i<256;++i)l[i]=r[i]=b<4?.8f:0.f;e.process(ptr,2,256,s);for(auto x:l)require(std::isfinite(x)&&std::abs(x)<=8,"Extreme feedback instability");if(b==400)for(auto& m:s.modules)m.v={{0,0,0}};}e.reset();for(int i=0;i<256;++i)l[i]=r[i]=0;e.process(ptr,2,256,s);for(auto x:l)require(x==0,"Reset retained old tail");}
 std::cout<<"PASS: 50 unique presets, mono/stereo, 4 sample rates, dry/bypass unity, all effect modes, max feedback, smoothing and reset.\n";
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
