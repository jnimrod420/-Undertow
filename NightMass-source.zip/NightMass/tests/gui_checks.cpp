#include "../Source/Plugin.h"
#include <iostream>
#include <stdexcept>
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter();
void require(bool ok,const char* message){if(!ok)throw std::runtime_error(message);}
juce::ComboBox* menu(juce::AudioProcessorEditor& e){for(int i=0;i<e.getNumChildComponents();++i)if(auto* c=dynamic_cast<juce::ComboBox*>(e.getChildComponent(i)))if(c->getName()=="Transmission preset")return c;throw std::runtime_error("Preset menu missing");}
int main(int argc,char** argv){juce::ScopedJuceInitialiser_GUI init;try{
 std::unique_ptr<NightMassProcessor> p(new NightMassProcessor);require(p->getNumPrograms()==50,"Missing presets");require(p->getParameters().size()==54,"Parameter count");
 for(int n=0;n<50;++n){p->setCurrentProgram(n);require(!p->modified(),"Preset values did not apply");auto expected=nightmass::factoryPresets[size_t(n)].settings;require(p->settings().order==expected.order,"Preset order wrong");require(p->settings().source==n/10,"Source mode wrong");}
 p->setCurrentProgram(0);std::unique_ptr<juce::AudioProcessorEditor> e(p->createEditor());int knobs=0;
 for(int i=0;i<e->getNumChildComponents();++i){auto* c=e->getChildComponent(i);if(auto* s=dynamic_cast<juce::Slider*>(c)){require(s->isVisible()&&e->getLocalBounds().contains(s->getBounds()),"Knob missing or outside editor");++knobs;}}require(knobs==27,"27 live knobs required");require(menu(*e)->getNumItems()==50,"Preset menu count");require(menu(*e)->getText()=="Graveyard shift","Preset name");
 p->swapStages(0,7);require(p->settings().order[0]==7,"Move stage failed");auto* param=p->state.getParameter("s4_p1");param->setValueNotifyingHost(.85f);juce::MessageManager::getInstance()->runDispatchLoopUntil(150);require(menu(*e)->getText().endsWith(" *"),"Edited marker missing");juce::MemoryBlock saved;p->getStateInformation(saved);p->setCurrentProgram(49);p->setStateInformation(saved.getData(),int(saved.getSize()));require(p->settings().order[0]==7,"Chain recall failed");require(std::abs(p->settings().modules[4].v[1]-.85)<.001,"Knob recall failed");
 e.reset();e.reset(p->createEditor());require(menu(*e)->getText()=="Graveyard shift *","Edited name recall failed");menu(*e)->setSelectedId(50,juce::sendNotificationSync);require(p->getCurrentProgram()==49&&!p->modified(),"Actual menu selection failed");
 p->setCurrentProgram(0);juce::MessageManager::getInstance()->runDispatchLoopUntil(150);
 if(argc>1){auto dir=juce::File::getCurrentWorkingDirectory().getChildFile(argv[1]);dir.createDirectory();auto image=e->createComponentSnapshot(e->getLocalBounds(),true,1);juce::FileOutputStream out(dir.getChildFile("NightMass-GUI.png"));require(out.openedOk()&&juce::PNGImageFormat().writeImageToStream(image,out),"Snapshot failed");}
 p->generate();require(p->selectedPreset()==-1,"Generated patch identity");require(p->modified()==false,"Generated marker");std::cout<<"PASS: 50 factory programs, values, source modes, 27 knobs, preset menu, chain ordering, state recall and generated patches.\n";
}catch(const std::exception& ex){std::cerr<<ex.what()<<'\n';return 1;}}
