#pragma once
#include "Plugin.h"
class NightMassLook final:public juce::LookAndFeel_V4 {
public:
 NightMassLook();juce::Font getComboBoxFont(juce::ComboBox&) override;
 juce::Label* createSliderTextBox(juce::Slider&) override;
 void drawComboBox(juce::Graphics&,int,int,bool,int,int,int,int,juce::ComboBox&) override;
 void drawRotarySlider(juce::Graphics&,int,int,int,int,float,float,float,juce::Slider&) override;
};
class NightMassEditor final:public juce::AudioProcessorEditor,private juce::Timer {
public:
 explicit NightMassEditor(NightMassProcessor&);~NightMassEditor() override;
 void paint(juce::Graphics&) override;void resized() override;
private:
 NightMassProcessor& processor;NightMassLook look;
 std::array<juce::Slider,24> knobs;juce::Slider mix,output,tempo;
 std::array<juce::ComboBox,8> modes;juce::ComboBox presets,source;
 std::array<juce::ToggleButton,8> enabled;
 std::array<juce::TextButton,8> left,right;
 juce::ToggleButton bypass,sync;juce::TextButton conjure{"CONJURE"};
 std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliders;
 std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> combos;
 std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttons;
 juce::TooltipWindow tips{this,600};std::array<int,8> lastOrder{{-1,-1,-1,-1,-1,-1,-1,-1}};
 void timerCallback() override;void addSlider(juce::Slider&,const juce::String&,bool db=false);
 JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(NightMassEditor)
};
