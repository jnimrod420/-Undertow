#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "Presets.h"
class NightMassProcessor final:public juce::AudioProcessor {
public:
 NightMassProcessor();
 void prepareToPlay(double,int) override;
 void releaseResources() override{}
 void reset() override {engine.reset();}
 void processBlock(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
 bool isBusesLayoutSupported(const BusesLayout&) const override;
 juce::AudioProcessorEditor* createEditor() override;
 bool hasEditor() const override{return true;}
 const juce::String getName() const override{return "Night Mass";}
 bool acceptsMidi() const override{return false;}bool producesMidi() const override{return false;}bool isMidiEffect() const override{return false;}
 double getTailLengthSeconds() const override{return 30;}
 int getNumPrograms() override{return 50;}int getCurrentProgram() override{return juce::jmax(0,selected.load());}
 void setCurrentProgram(int) override;const juce::String getProgramName(int) override;
 void changeProgramName(int,const juce::String&) override{}
 void getStateInformation(juce::MemoryBlock&) override;void setStateInformation(const void*,int) override;
 juce::AudioProcessorValueTreeState state;
 nightmass::Settings settings() const;
 void apply(const nightmass::Settings&);void swapStages(int,int);void generate();bool modified() const;
 int selectedPreset() const{return selected.load();}
 static juce::String key(int stage,const char* field){return "s"+juce::String(stage)+"_"+field;}
private:
 static juce::AudioProcessorValueTreeState::ParameterLayout layout();
 nightmass::Engine engine;std::atomic<int> selected{-1};
 std::array<std::atomic<float>*,8> on{},mode{},order{};
 std::array<std::array<std::atomic<float>*,3>,8> v{};
 std::atomic<float>* source=nullptr,*mix=nullptr,*output=nullptr,*bypass=nullptr,*sync=nullptr,*tempo=nullptr;
 void set(const juce::String&,float);
 JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(NightMassProcessor)
};
