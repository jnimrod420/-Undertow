#pragma once
#include "Engine.h"
namespace nightmass {
inline const char* sourceNames[]={"Guitar","Bass","Drums","Synth","Vocals"};
inline const char* stageNames[]={"Grip","Bite","Veil","Fracture","Wander","Echoes","Crypt","Pulse"};
inline const char* stageHelp[]={"Linked compressor: threshold, ratio/release, blend","Overdrive and cabinet tone: drive, brightness, blend","Resonant filter: cutoff, resonance, blend","Fuzz or digital erosion: drive/rate, hardness/bits, blend","Chorus, vibrato or flange: speed, depth, blend","Delay: time/division, feedback, blend","Feedback reverb: decay/size, damping, blend","Rhythmic volume: rate, curve, depth"};
inline const char* knobNames[8][3]={{"Squeeze","Release"},{"Drive","Tone"},{"Cutoff","Resonance"},{"Damage","Texture"},{"Rate","Depth"},{"Time","Feedback"},{"Decay","Damping"},{"Rate","Curve"}};
inline const char* modeNames[8][3]={{"Slow","Fast",nullptr},{"Warm","Hot",nullptr},{"Low pass","High pass","Band pass"},{"Fuzz","Digital",nullptr},{"Chorus","Vibrato","Flange"},{"Tape","Clean","Ping pong"},{"Chamber","Hall",nullptr},{"Swell",nullptr,nullptr}};
inline const char* presetNames[]={"Graveyard shift","Velvet coffin","Silver stake","Wrong timeline","Cathedral static","Low blood pressure","Buried heartbeat","Iron appetite","Basement ritual","Black procession","Concrete pulse","Rust communion","Dead disco","Ashes on tape","Machine funeral","Midnight transmission","Neon crypt","Cold apparition","Dream infection","Last light","Whisper at the window","Vampire radio","Choir of the missing","Siren in the fallout","Final confession", "After the last train","Porcelain teeth","Cemetery weather","Tarnished halo","Static exorcism","Underground hunger","Sewer saint","Slow collapse","Dead transmission","Subterranean choir","Bones on the dancefloor","Broken metronome","Tin coffin","Blood machine","Fallout ballroom","Red moon signal","Spectral bloom","Velvet eclipse","Endless October","The wrong sunrise","Breath behind glass","Black chapel","Death in stereo","Blood oath","Nobody comes home"};
struct Preset {const char* name;Settings settings;};
inline std::array<Preset,50> makePresets(){
 std::array<Preset,50> result{};
 for(int n=0;n<50;++n){Settings s;s.source=n/10;int voice=n%5;bool alternate=(n%10)>=5;
  s.modules[0]={true,s.source==2?1:0,{{.2+.055*voice,.35+.08*voice,.45}}};
  s.modules[1]={true,voice==2?1:0,{{.12+.065*voice,s.source==1?.38:.62,.65}}};
  s.modules[2]={voice==3||voice==4,voice==3?1:0,{{voice==3?.23:.73,.28,.65}}};
  s.modules[3]={voice==2||voice==4,voice==4?1:0,{{.18+.08*voice,.34,.3}}};
  s.modules[4]={s.source!=2,voice==3?2:0,{{.12+.06*voice,.25+.09*voice,s.source==1?.16:.48}}};
  s.modules[5]={true,voice==1?2:0,{{voice==0?.58:.38,.22+.08*voice,s.source==1?.09:.22+.05*voice}}};
  s.modules[6]={s.source!=1,voice==1||voice==4?1:0,{{.18+.13*voice,.3,s.source==2?.12:.22+.08*voice}}};
  s.modules[7]={voice==3||s.source==2,0,{{voice==3?.78:.45,.5,s.source==2?.2:.35}}};
  s.output=-1.5-voice*.6;s.mix=1;
  if(s.source==4){s.modules[1].v[0]*=.5;s.modules[0].v[0]+=.15;}
  if(s.source==3){s.modules[4].v[1]+=.12;s.modules[6].v[2]+=.1;}
  if(voice==4)s.order={{0,2,1,4,3,5,6,7}};
  if(alternate){s.modules[4].mode=voice%3;s.modules[4].v[0]=.07+.08*voice;s.modules[5].mode=2;s.modules[5].v[0]=.78;s.modules[5].v[1]=.18+.1*voice;s.modules[6].mode=1;s.modules[6].v[0]=.32+.1*voice;s.modules[6].v[2]*=.65;s.modules[2].on=true;s.modules[2].mode=voice==2?2:0;s.modules[2].v[0]=.6+.07*voice;s.modules[3].on=voice==1||voice==4;s.modules[3].v[2]=.18;s.modules[7].on=voice==0||voice==3;s.modules[7].v[2]=.22;s.order={{0,2,3,1,4,6,5,7}};s.output-=1; }
  int nameIndex=alternate?25+s.source*5+voice:s.source*5+voice;result[size_t(n)]={presetNames[nameIndex],s};
 }return result;
}
inline const auto factoryPresets=makePresets();
}
