#pragma once
#include <array>
#include <vector>
#include <cmath>
#include <algorithm>
namespace nightmass {
constexpr double pi=3.14159265358979323846;
inline double clamp(double x,double lo,double hi){return std::max(lo,std::min(hi,x));}
struct Module { bool on=true; int mode=0; std::array<double,3> v{{.3,.5,.25}}; };
struct Settings { int source=0; std::array<Module,8> modules{}; std::array<int,8> order{{0,1,2,3,4,5,6,7}}; double mix=1,output=0; bool bypass=false,sync=true; double bpm=120; };
struct DelayLine {
 std::vector<double> data; size_t pos=0;
 void prepare(size_t n){data.assign(n,0);pos=0;}
 void reset(){std::fill(data.begin(),data.end(),0);pos=0;}
 double read(double samples) const { samples=clamp(samples,1,double(data.size()-2)); double p=double(pos)-samples; if(p<0)p+=double(data.size());auto i=size_t(p);auto j=(i+1)%data.size();return data[i]+(data[j]-data[i])*(p-double(i)); }
 void push(double x){data[pos]=x;pos=(pos+1)%data.size();}
};
class Engine {
 double sr=48000,phase=0,pumpPhase=0,smoothing=1-std::exp(-1/(.025*48000)); Settings current{}; bool initialized=false;
 std::array<double,2> env{},hp{},preLP{},low{},band{},echoLP{},rvLP{};
 std::array<double,2> held{}; std::array<int,2> holdCount{};
 std::array<DelayLine,2> chorus,echo; std::array<DelayLine,8> rv;
 static double finite(double x){return std::isfinite(x)?x:0;}
 double slew(double x,double target){return x+(target-x)*smoothing;}
public:
 void prepare(double sampleRate){sr=clamp(sampleRate,8000,192000);smoothing=1-std::exp(-1/(.025*sr));for(auto& d:chorus)d.prepare(size_t(sr*.08)+4);for(auto& d:echo)d.prepare(size_t(sr*3)+4);for(auto& d:rv)d.prepare(size_t(sr*.23)+4);reset();}
 void reset(){phase=pumpPhase=0;env={};hp={};preLP={};low={};band={};echoLP={};rvLP={};held={};holdCount={};for(auto& d:chorus)d.reset();for(auto& d:echo)d.reset();for(auto& d:rv)d.reset();initialized=false;}
 void process(float* const* channels,int count,int samples,const Settings& target){
  if(!initialized){current=target;initialized=true;}
  current.source=target.source;current.order=target.order;current.sync=target.sync;current.bpm=target.bpm;
  for(int k=0;k<8;++k){current.modules[size_t(k)].on=target.modules[size_t(k)].on;current.modules[size_t(k)].mode=target.modules[size_t(k)].mode;}
  for(int i=0;i<samples;++i){
   current.mix=slew(current.mix,target.mix);current.output=slew(current.output,target.output);
   for(int k=0;k<8;++k)for(int p=0;p<3;++p)current.modules[size_t(k)].v[size_t(p)]=slew(current.modules[size_t(k)].v[size_t(p)],target.modules[size_t(k)].v[size_t(p)]);
   double dry[2]={finite(channels[0][i]),count>1?finite(channels[1][i]):finite(channels[0][i])};double x[2]={dry[0],dry[1]};
   const double bpm=clamp(current.bpm,30,300);const auto source=current.source;
   for(int stage:current.order){if(stage<0||stage>7)continue;const auto& m=current.modules[size_t(stage)];if(!m.on)continue;double a=m.v[0],b=m.v[1],wet=m.v[2];double y[2]={x[0],x[1]};
    if(stage==0){ // linked feed-forward compressor
     double peak=std::max(std::abs(x[0]),std::abs(x[1]));double tau=peak>env[0]?(m.mode==0?.012:.001):(.07+b*.65);env[0]+=(peak-env[0])*(1-std::exp(-1/(tau*sr)));
     double threshold=std::pow(10.,(-6-30*a)/20.),ratio=2+b*8;double gain=env[0]>threshold?std::pow(env[0]/threshold,1/ratio-1):1;double makeup=std::pow(10.,a*6/20.);for(int ch=0;ch<2;++ch)y[ch]=x[ch]*gain*makeup;
    } else if(stage==1){ // source-voiced drive / dark cabinet
     double drive=1+a*(m.mode==0?8:25);double cut=source==1?25:source==4?95:60;double h=1-std::exp(-2*pi*cut/sr);double l=1-std::exp(-2*pi*(700+std::pow(b,2)*11500)/sr);
     for(int ch=0;ch<2;++ch){hp[size_t(ch)]+=h*(x[ch]-hp[size_t(ch)]);double z=std::tanh((x[ch]-hp[size_t(ch)])*drive)/std::sqrt(drive);preLP[size_t(ch)]+=l*(z-preLP[size_t(ch)]);y[ch]=preLP[size_t(ch)];}
    } else if(stage==2){ // topology-preserving state variable filter
     double fc=80*std::pow(160.,a);fc=std::min(fc,sr*.43);double g=std::tan(pi*fc/sr),k=2-1.75*b;
     for(int ch=0;ch<2;++ch){auto c=size_t(ch);double v1=(g*(x[ch]-low[c])+band[c])/(1+g*(g+k));double v2=low[c]+g*v1;band[c]=2*v1-band[c];low[c]=2*v2-low[c];double high=x[ch]-k*v1-v2;y[ch]=m.mode==0?v2:m.mode==1?high:v1;}
    } else if(stage==3){ // fuzz / sample hold bit reduction
     for(int ch=0;ch<2;++ch){auto c=size_t(ch);if(m.mode==0){double drive=1+a*40;y[ch]=std::tanh(x[ch]*drive)/std::sqrt(drive);double z=clamp(x[ch]*(1+a*12),-1,1);y[ch]=y[ch]*(1-b)+z*b;}else{int hop=1+int(a*38);if(holdCount[c]--<=0){holdCount[c]=hop-1;double steps=std::pow(2.,4+(1-b)*12);held[c]=std::round(x[ch]*steps)/steps;}y[ch]=held[c];}}
    } else if(stage==4){ // chorus / vibrato / flange
     double rate=.08+a*4;phase+=rate/sr;phase-=std::floor(phase);for(int ch=0;ch<2;++ch){double lfo=std::sin(2*pi*(phase+ch*.25));double base=m.mode==2?.003:.017;double depth=(m.mode==2?.002:.009)*b;double z=chorus[size_t(ch)].read((base+depth*lfo)*sr);chorus[size_t(ch)].push(x[ch]+(m.mode==2?z*.45:0));y[ch]=m.mode==1?z:(x[ch]+z)*.70710678;}
    } else if(stage==5){ // tempo delay / tape / ping pong
     static const double beats[]={.25,.5,.75,1,1.5,2};double sec=current.sync?60/bpm*beats[std::min(5,int(a*5.999))]:.025+a*1.975;
     double z[2];for(int ch=0;ch<2;++ch){z[ch]=echo[size_t(ch)].read(sec*sr);double f=m.mode==0?2200:11000;echoLP[size_t(ch)]+=(1-std::exp(-2*pi*f/sr))*(z[ch]-echoLP[size_t(ch)]);z[ch]=echoLP[size_t(ch)];}
     for(int ch=0;ch<2;++ch){echo[size_t(ch)].push(std::tanh(x[ch]+z[m.mode==2?1-ch:ch]*b*.88));y[ch]=x[ch]+z[ch];}
    } else if(stage==6){ // four-line orthogonal feedback network
     const double times[]={.0297,.0371,.0411,.0437};double z[2][4];for(int ch=0;ch<2;++ch)for(int j=0;j<4;++j)z[ch][j]=rv[size_t(ch*4+j)].read((times[j]*(m.mode==0?1:1.8)*(1+a*2)+ch*.0013)*sr);
     double feedback=.25+a*.70;double damp=1-std::exp(-2*pi*(800+(1-b)*10500)/sr);
     for(int ch=0;ch<2;++ch){double sum=(z[ch][0]+z[ch][1]+z[ch][2]+z[ch][3])*.5;rvLP[size_t(ch)]+=damp*(sum-rvLP[size_t(ch)]);for(int j=0;j<4;++j){double h=z[ch][j]-sum;rv[size_t(ch*4+j)].push(x[ch]*.22+std::tanh(h)*feedback);}y[ch]=x[ch]+rvLP[size_t(ch)];}
    } else { // host-position-synced rhythmic attenuation
     double rate=current.sync?bpm/60*(a<.33?.5:a<.66?1:2):.2+a*7;double curve=m.mode==0?std::pow(.5-.5*std::cos(2*pi*pumpPhase),.3+b*3):.5+.5*std::tanh(std::sin(2*pi*pumpPhase)*(1+b*12));for(int ch=0;ch<2;++ch)y[ch]=x[ch]*(1-wet+wet*curve);pumpPhase+=rate/sr;pumpPhase-=std::floor(pumpPhase);wet=1;
    }
    for(int ch=0;ch<2;++ch)x[ch]=finite(x[ch]+(y[ch]-x[ch])*wet);
   }
   double gain=std::pow(10.,current.output/20.);
   for(int ch=0;ch<count;++ch){double result=target.bypass?dry[ch]:gain*(dry[ch]+(x[ch]-dry[ch])*current.mix);channels[ch][i]=float(clamp(finite(result),-8,8));}
  }
 }
 void setBeatPosition(double ppq,const Settings& s){double mult=s.modules[7].v[0]<.33?.5:s.modules[7].v[0]<.66?1:2;pumpPhase=ppq*mult-std::floor(ppq*mult);}
};
}
