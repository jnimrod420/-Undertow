# Validation status

Completed locally:
- Engine compiled with GCC C++17, optimization and warnings.
- All 50 named presets are unique and generate distinct outputs on the reference signal.
- Every preset processes mono/stereo at 44.1, 48, 96 and 192 kHz.
- Dry mix and global bypass preserve input at unity.
- All module modes, maximum feedback, a reversed chain, parameter smoothing and reset were stressed.
- JUCE 8.0.12 syntax/type checks cover processor, editor, GUI/session tests and VST3 host tests.

Pending native CI execution:
- Linked macOS universal VST3/AU builds and Windows x64 VST3 build.
- GUI rendering and visual inspection.
- Actual VST3 scan/load and parameter/session tests on both platforms.
- Windows installer compilation, silent installation, exact payload hashes, installed plugin loading and uninstallation.

GitHub application write operations returned HTTP 403 (resource not accessible by integration). Source and workflow are ready; a write-capable route is required to start native CI. No platform binary or installer executable has been created yet.
