#ifndef PluginDir
#define PluginDir "..\..\build-nightmass\NightMass_artefacts\Release\VST3\Night Mass.vst3"
#endif
[Setup]
AppId={{9E0A3728-7F3C-4C5C-96AC-F71D4F8D8920}
AppName=Night Mass
AppVersion=1.0.0
AppPublisher=Nobody But Ghosts
DefaultDirName={commoncf64}\VST3
DisableDirPage=yes
DisableProgramGroupPage=yes
UninstallFilesDir={autopf}\Nobody But Ghosts\Night Mass
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=admin
OutputDir=..\..\dist-nightmass
OutputBaseFilename=NightMass-1.0.0-Windows-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
SetupLogging=yes
[Files]
Source: "{#PluginDir}\*"; DestDir: "{app}\Night Mass.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
[UninstallDelete]
Type: dirifempty; Name: "{app}\Night Mass.vst3"
[Messages]
WelcomeLabel2=This will install Night Mass 1.0.0 by Nobody But Ghosts for 64-bit Windows VST3 hosts.%n%nClose REAPER or your audio host before continuing. After installation, reopen your host and rescan VST3 plugins.
FinishedLabel=Night Mass has been installed. Open your audio host, rescan VST3 plugins, and select Night Mass.
