# Night Mass — 50 factory presets

Each source has ten presets. Preset names and parameter values are original.

| Source | Presets |
|---|---|
| Guitar | Graveyard shift, Velvet coffin, Silver stake, Wrong timeline, Cathedral static, After the last train, Porcelain teeth, Cemetery weather, Tarnished halo, Static exorcism |
| Bass | Low blood pressure, Buried heartbeat, Iron appetite, Basement ritual, Black procession, Underground hunger, Sewer saint, Slow collapse, Dead transmission, Subterranean choir |
| Drums | Concrete pulse, Rust communion, Dead disco, Ashes on tape, Machine funeral, Bones on the dancefloor, Broken metronome, Tin coffin, Blood machine, Fallout ballroom |
| Synth | Midnight transmission, Neon crypt, Cold apparition, Dream infection, Last light, Red moon signal, Spectral bloom, Velvet eclipse, Endless October, The wrong sunrise |
| Vocals | Whisper at the window, Vampire radio, Choir of the missing, Siren in the fallout, Final confession, Breath behind glass, Black chapel, Death in stereo, Blood oath, Nobody comes home |
