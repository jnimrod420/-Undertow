#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ "$(uname -s)" != Darwin ]]; then
  echo 'This installer is for macOS. On other systems copy Reaper/EchoesAndDepartures.jsfx into your REAPER resource Effects folder.'
  exit 1
fi
reaper_effects="$HOME/Library/Application Support/REAPER/Effects/NobodyButGhosts"
mkdir -p "$reaper_effects"
cp Reaper/EchoesAndDepartures.jsfx "$reaper_effects/EchoesAndDepartures.jsfx"
echo 'Installed EchoesAndDepartures for REAPER. Open the FX browser, press F5, and search EchoesAndDepartures.'
echo 'Portable/custom REAPER installs: use Options > Show REAPER resource path and copy the .jsfx into Effects.'
read -r -p 'Press Enter to close.'
