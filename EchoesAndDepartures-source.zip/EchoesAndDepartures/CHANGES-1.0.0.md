# Echoes & Departures 1.0.0

- Complete Nobody But Ghosts identity: plugin name, bundle, host parameter names and new plugin ID.
- Approved worn silver artwork, wandering typewriter stamps and enlarged pixel ghost.
- Interactive black knobs, engraved tick marks and clear numeric readouts.
- Pulse (Rate), Wander (Depth), Haze (Damp), Veil (LPG), Presence (Mix), Voice (Volume).
- Unknown transmission replaces Custom settings. Preset names remain visible; * marks edits.
- Same DSP and 20 preset values as verified Undertow 0.1.2.
