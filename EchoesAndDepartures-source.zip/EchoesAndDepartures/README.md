# Echoes & Departures

An original random pitch-drift and dynamic low-pass effect by Nobody But Ghosts. Six controls: Pulse, Wander, Haze, Veil, Presence and Voice. Twenty factory presets. Worn silver faceplate with wandering typewriter stamps and a pixel ghost.

This is the fully rebranded successor to Undertow, with a distinct plugin identity and EchoesAndDepartures.vst3 bundle. Audio processing and preset values match the verified Undertow 0.1.2 engine. It does not replace Undertow in existing projects.

Mac universal arm64/x86_64 VST3 and Windows x64 VST3. Source is MIT licensed; JUCE has separate terms. The algorithm is an original behavioral approximation, not an official or hardware-calibrated Fairfield product.
