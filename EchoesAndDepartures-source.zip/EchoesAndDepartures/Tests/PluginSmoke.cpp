#include <juce_audio_utils/juce_audio_utils.h>
#include <iostream>
#include <stdexcept>
void require(bool condition, const char* message) { if (!condition) throw std::runtime_error(message); }
juce::AudioProcessorParameter* findParameter(juce::AudioProcessor& plugin, const juce::String& name) {
    for (auto* p : plugin.getParameters()) if (p->getName(64) == name) return p;
    throw std::runtime_error("Missing parameter: " + name.toStdString());
}
int main(int argc, char** argv) {
    juce::ScopedJuceInitialiser_GUI initialise;
    try {
        require(argc >= 2, "Expected VST3 bundle path");
        juce::AudioPluginFormatManager manager;
        manager.addFormat(new juce::VST3PluginFormat());
        juce::OwnedArray<juce::PluginDescription> descriptions;
        manager.getFormat(0)->findAllTypesForFile(descriptions, juce::String(argv[1]));
        require(!descriptions.isEmpty(), "VST3 scan returned no plugin");
        juce::String error;
        auto plugin = manager.createPluginInstance(*descriptions[0], 48000, 256, error);
        if (!plugin) throw std::runtime_error("VST3 load failed: " + error.toStdString());
        for (const char* name : {"Pulse", "Wander", "Haze", "Veil", "Presence", "Voice"}) findParameter(*plugin, name);
        require(plugin->getNumPrograms()==20,"Loaded VST3 factory programs missing");
        plugin->setCurrentProgram(12);
        require(std::abs(findParameter(*plugin,"Wander")->getValue()-1.0f)<.0001f,"Loaded VST3 program selection failed");
        auto* depth = findParameter(*plugin, "Wander");
        depth->setValueNotifyingHost(.27f);
        juce::MemoryBlock state; plugin->getStateInformation(state);
        require(state.getSize() > 0, "Empty saved state");
        depth->setValueNotifyingHost(.8f);
        plugin->setStateInformation(state.getData(), static_cast<int>(state.getSize()));
        require(std::abs(depth->getValue() - .27f) < .0001f, "State restore failed");
        findParameter(*plugin, "Presence")->setValueNotifyingHost(0.0f);
        findParameter(*plugin, "Voice")->setValueNotifyingHost(24.0f/36.0f);
        for (int channels : {1, 2}) {
            auto layout = plugin->getBusesLayout();
            layout.inputBuses.set(0, channels == 1 ? juce::AudioChannelSet::mono() : juce::AudioChannelSet::stereo());
            layout.outputBuses.set(0, layout.inputBuses[0]);
            require(plugin->setBusesLayout(layout), "Channel layout rejected");
            for (double sr : {44100.0, 48000.0, 96000.0}) {
                plugin->setRateAndBufferSizeDetails(sr, 256); plugin->prepareToPlay(sr, 256);
                juce::AudioBuffer<float> buffer(channels, 256); juce::MidiBuffer midi;
                for (int ch = 0; ch < channels; ++ch)
                    for (int i = 0; i < 256; ++i) buffer.setSample(ch, i, .2f*std::sin(.05f*static_cast<float>(i)));
                juce::AudioBuffer<float> reference; reference.makeCopyOf(buffer);
                plugin->processBlock(buffer, midi);
                for (int ch = 0; ch < channels; ++ch)
                    for (int i = 0; i < 256; ++i)
                        require(std::abs(buffer.getSample(ch,i)-reference.getSample(ch,i))<1e-6f,"Dry audio changed in loaded VST3");
                findParameter(*plugin, "Presence")->setValueNotifyingHost(1.0f);
                for (int block = 0; block < 32; ++block) {
                    for (int ch = 0; ch < channels; ++ch)
                        for (int i = 0; i < 256; ++i) buffer.setSample(ch,i,.2f*std::sin(.05f*static_cast<float>(i+block*256)));
                    plugin->processBlock(buffer,midi);
                    for (int ch = 0; ch < channels; ++ch)
                        for (int i = 0; i < 256; ++i) require(std::isfinite(buffer.getSample(ch,i)),"Non-finite wet audio");
                }
                plugin->releaseResources();findParameter(*plugin,"Presence")->setValueNotifyingHost(0.0f);
            }
        }
        {
            std::unique_ptr<juce::AudioProcessorEditor> editor(plugin->createEditorIfNeeded());
            require(editor != nullptr, "Editor failed to open");
            auto image=editor->createComponentSnapshot(editor->getLocalBounds());
            require(image.isValid(), "Editor snapshot failed");
            if (argc >= 3) {
                auto outFile=juce::File::getCurrentWorkingDirectory().getChildFile(argv[2]);
                juce::FileOutputStream stream(outFile); require(stream.openedOk(), "Cannot write preview");
                juce::PNGImageFormat png; require(png.writeImageToStream(image,stream), "Cannot encode preview");
            }
        }
        std::cout << "PASS: actual VST3 scan/load, six controls, session recall, mono/stereo audio, three sample rates, wet stability, editor creation.\n";
        return 0;
    } catch (const std::exception& e) { std::cerr << "FAIL: " << e.what() << '\n';return 1; }
}
