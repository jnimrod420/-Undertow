#include "PluginProcessor.h"
#include <iostream>
#include <stdexcept>
void require(bool ok,const char* message) { if(!ok) throw std::runtime_error(message); }
juce::ComboBox* findMenu(juce::AudioProcessorEditor& editor) {
    for(int i=0;i<editor.getNumChildComponents();++i)
        if(auto* menu=dynamic_cast<juce::ComboBox*>(editor.getChildComponent(i))) return menu;
    throw std::runtime_error("Preset menu missing");
}
int main(int argc,char** argv) {
    juce::ScopedJuceInitialiser_GUI init;
    try {
        EchoesAndDeparturesProcessor processor;
        require(processor.getNumPrograms()==20,"Factory program count");
        const char* ids[]={"pulse","wander","haze","veil","presence","voice"};
        for(int n=0;n<20;++n) {
            processor.setCurrentProgram(n);
            require(processor.getSelectedPreset()==n,"Preset selection lost");
            require(!processor.isPresetModified(),"Fresh preset marked edited");
            for(size_t i=0;i<6;++i)
                require(std::abs(processor.state.getRawParameterValue(ids[i])->load()-echoes::factoryPresets[static_cast<size_t>(n)].values[i])<.051f,"Preset value wrong");
            std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
            auto* menu=findMenu(*editor);
            require(menu->getNumItems()==20,"Menu entries missing");
            require(menu->getText()==processor.getProgramName(n),"Selected name not visible");
        }
        processor.setCurrentProgram(12);
        auto* depth=processor.state.getParameter("wander");
        depth->setValueNotifyingHost(.81f);
        require(processor.isPresetModified(),"Edited marker missing");
        juce::MemoryBlock saved; processor.getStateInformation(saved);
        processor.setCurrentProgram(0);
        processor.setStateInformation(saved.getData(),static_cast<int>(saved.getSize()));
        require(processor.getSelectedPreset()==12,"Session lost preset identity");
        require(std::abs(depth->getValue()-.81f)<.0001f,"Session lost edited knob");
        {
            std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
            require(findMenu(*editor)->getText()=="Seasick cassette *","Reopened editor label wrong");
        }
        // Old sessions have no preset metadata; preserve knobs and show Unknown transmission.
        auto legacy=processor.state.copyState().createXml(); legacy->removeAttribute("factoryPreset");
        juce::MemoryBlock old; juce::AudioProcessor::copyXmlToBinary(*legacy,old);
        processor.setStateInformation(old.getData(),static_cast<int>(old.getSize()));
        require(processor.getSelectedPreset()==-1,"Legacy session preset falsely identified");
        std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
        require(findMenu(*editor)->getText()=="Unknown transmission","Custom session label wrong");
        editor.reset();processor.setCurrentProgram(0);editor.reset(processor.createEditor());
        int sliders=0;
        for(int i=0;i<editor->getNumChildComponents();++i)
            if(auto* slider=dynamic_cast<juce::Slider*>(editor->getChildComponent(i))) {
                require(slider->isVisible() && slider->getWidth()>100,"Interactive knob missing");
                ++sliders;
            }
        require(sliders==6,"Expected six live knobs");
        require(processor.getName()=="Echoes & Departures","Brand name wrong");
        require(editor->getWidth()==980 && editor->getHeight()==700,"GUI size mismatch");
        auto preview=editor->createComponentSnapshot(editor->getLocalBounds(),true,1.0f);
        require(preview.isValid(),"GUI preview unavailable");
        require(preview.getPixelAt(490,350)!=preview.getPixelAt(10,10),"GUI preview blank");
        if(argc>1) {
            auto file=juce::File::getCurrentWorkingDirectory().getChildFile(argv[1]);
            file.getParentDirectory().createDirectory();
            juce::FileOutputStream stream(file);
            require(stream.openedOk(),"Cannot write GUI preview");
            juce::PNGImageFormat png;require(png.writeImageToStream(preview,stream),"Cannot encode GUI preview");
        }
        std::cout<<"PASS: 20 factory programs, all knob values, visible menu names, edited marker, preset and knob session recall, editor reopen, legacy sessions.\n";
        return 0;
    } catch(const std::exception& e) {std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}
}
