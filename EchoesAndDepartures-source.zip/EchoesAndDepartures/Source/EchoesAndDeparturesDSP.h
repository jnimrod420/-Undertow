#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>

// Original behavioural model, not a circuit simulation. No framework dependency.
namespace echoes {
struct Parameters {
    double rate = 0.36, depth = 0.32, damp = 0.55, lpg = 0.70, mix = 0.50, volumeDb = 0.0;
};
class Engine {
public:
    void prepare(double sampleRate, uint32_t seed = 0x6e624731u) {
        sr = std::clamp(sampleRate, 8000.0, 384000.0);
        size = static_cast<int>(std::ceil(sr * 0.06)) + 8;
        for (auto& c : channels) { c = {}; c.delay.assign(static_cast<size_t>(size), 0.0); }
        initialSeed = seed % 2147483647u; if (!initialSeed) initialSeed = 1; rng = initialSeed; write = 0; remaining = 0;
        target = mod1 = mod2 = envelope = 0.0;
        smoothing = 1.0 - std::exp(-1.0 / (0.025 * sr));
        attack = 1.0 - std::exp(-1.0 / (0.004 * sr));
        release = 1.0 - std::exp(-1.0 / (0.160 * sr));
        preCoeff = 1.0 - std::exp(-2.0 * pi * std::min(9000.0, sr * 0.20) / sr);
        dcCoeff = std::exp(-2.0 * pi * 12.0 / sr);
        current = desired;
    }
    void reset() noexcept {
        for (auto& c : channels) {
            std::fill(c.delay.begin(), c.delay.end(), 0.0);
            c.pre1=c.pre2=c.low1=c.low2=c.prevIn=c.prevOut=0.0;
        }
        rng=initialSeed; write=remaining=0; target=mod1=mod2=envelope=0.0; current=desired;
    }
    void setParameters(Parameters p, bool immediate = false) noexcept {
        desired = sanitise(p);
        if (immediate) current = desired;
    }
    // One or two channels; linked modulation and envelope preserve a stereo image.
    void process(float* const* data, int count, int samples) noexcept {
        count = std::clamp(count, 1, 2);
        if (size == 0) return;
        for (int i = 0; i < samples; ++i) {
            smooth(current.rate, desired.rate); smooth(current.depth, desired.depth);
            smooth(current.damp, desired.damp); smooth(current.lpg, desired.lpg);
            smooth(current.mix, desired.mix); smooth(current.volumeDb, desired.volumeDb);
            double input[2] = {}; double peak = 0;
            for (int ch = 0; ch < count; ++ch) {
                input[ch] = std::isfinite(data[ch][i]) ? data[ch][i] : 0.0;
                peak = std::max(peak, std::abs(input[ch]));
            }
            envelope += (peak > envelope ? attack : release) * (peak - envelope);
            if (--remaining <= 0) {
                target = 2.0 * random01() - 1.0;
                double hz = 0.10 * std::pow(100.0, current.rate);
                remaining = std::max(1, static_cast<int>(sr * (0.4 + 1.2 * random01()) / hz));
            }
            double tau = 0.018 * std::pow(80.0, current.damp);
            double modCoeff = 1.0 - std::exp(-1.0 / (tau * sr));
            mod1 += modCoeff * (target - mod1);
            mod2 += modCoeff * (mod1 - mod2);
            double delaySamples = sr * (0.020 + 0.005 * current.depth * current.depth * mod2);
            double l = current.lpg;
            double opened = std::clamp(envelope * (2.0 + 78.0 * l * l), 0.0, 1.0);
            double floorHz = 140.0 + 2200.0 * l * l * l;
            double cutoff = floorHz * std::pow(9000.0 / floorHz, opened);
            cutoff = std::min(cutoff, sr * 0.20);
            double fc = 1.0 - std::exp(-2.0 * pi * cutoff / sr);
            double gate = std::clamp(0.04 + 0.65 * std::pow(l, 4.0)
                              + envelope * (4.0 + 120.0 * l * l * l), 0.04, 1.0);
            // Compensate the equal-level blend dip; add 3 dB to the filtered wet path.
            // Fixed gain preserves the LPG envelope rather than normalising quiet tails.
            double mixGain = 1.0 / std::sqrt((1.0-current.mix)*(1.0-current.mix) + current.mix*current.mix);
            double gain = std::pow(10.0, current.volumeDb / 20.0) * mixGain;
            for (int ch = 0; ch < count; ++ch) {
                auto& c = channels[static_cast<size_t>(ch)];
                c.pre1 += preCoeff * (input[ch] - c.pre1);
                c.pre2 += preCoeff * (c.pre1 - c.pre2);
                // Mild saturation in the wet path only. No generated noise.
                c.delay[static_cast<size_t>(write)] = std::tanh(0.9 * c.pre2) / 0.9;
                double wet = readDelay(c, delaySamples);
                c.low1 += fc * (wet - c.low1);
                c.low2 += fc * (c.low1 - c.low2);
                wet = c.low2 * gate;
                double dc = wet - c.prevIn + dcCoeff * c.prevOut;
                c.prevIn = wet; c.prevOut = dc;
                // Preserve the dry/wet ratio and intentional comb filtering. Dry-only remains unity.
                data[ch][i] = static_cast<float>(gain * ((1.0 - current.mix) * input[ch] + current.mix * 1.4125375446227544 * dc));
            }
            if (++write >= size) write = 0;
        }
    }
private:
    static constexpr double pi = 3.14159265358979323846;
    struct Channel { std::vector<double> delay; double pre1=0, pre2=0, low1=0, low2=0, prevIn=0, prevOut=0; };
    std::array<Channel, 2> channels;
    Parameters current, desired;
    double sr=48000, smoothing=0, attack=0, release=0, preCoeff=0, dcCoeff=0;
    double target=0, mod1=0, mod2=0, envelope=0;
    int size=0, write=0, remaining=0; uint32_t rng=1, initialSeed=1;
    static double finite(double x, double fallback) noexcept { return std::isfinite(x) ? x : fallback; }
    static Parameters sanitise(Parameters p) noexcept {
        p.rate=std::clamp(finite(p.rate,.36),0.0,1.0);
        p.depth=std::clamp(finite(p.depth,.32),0.0,1.0);
        p.damp=std::clamp(finite(p.damp,.55),0.0,1.0);
        p.lpg=std::clamp(finite(p.lpg,.7),0.0,1.0);
        p.mix=std::clamp(finite(p.mix,.5),0.0,1.0);
        p.volumeDb=std::clamp(finite(p.volumeDb,0),-24.0,12.0); return p;
    }
    void smooth(double& a, double b) const noexcept { a += smoothing * (b-a); }
    double random01() noexcept {
        rng = static_cast<uint32_t>((static_cast<uint64_t>(rng) * 16807u) % 2147483647u);
        return static_cast<double>(rng) / 2147483647.0;
    }
    double readDelay(const Channel& c, double delay) const noexcept {
        double pos = static_cast<double>(write) - delay;
        if (pos < 0) pos += size;
        int index = static_cast<int>(pos); double f = pos-index;
        auto at = [&](int n) { if(n<0)n+=size; if(n>=size)n-=size; return c.delay[static_cast<size_t>(n)]; };
        double y0=at(index-1), y1=at(index), y2=at(index+1), y3=at(index+2);
        return y1 + 0.5*f*(y2-y0 + f*(2*y0-5*y1+4*y2-y3 + f*(3*(y1-y2)+y3-y0)));
    }
};
}
