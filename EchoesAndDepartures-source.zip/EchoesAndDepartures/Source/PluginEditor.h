#pragma once
#include "PluginProcessor.h"
class EchoesAndDeparturesLook final : public juce::LookAndFeel_V4 {
public:
    EchoesAndDeparturesLook();
    juce::Font getComboBoxFont(juce::ComboBox&) override;
    juce::Label* createSliderTextBox(juce::Slider&) override;
    void drawComboBox(juce::Graphics&,int,int,bool,int,int,int,int,juce::ComboBox&) override;
    void drawRotarySlider(juce::Graphics&,int,int,int,int,float,float,float,juce::Slider&) override;
};
class EchoesAndDeparturesEditor final : public juce::AudioProcessorEditor, private juce::Timer {
public:
    explicit EchoesAndDeparturesEditor(EchoesAndDeparturesProcessor&);
    ~EchoesAndDeparturesEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    EchoesAndDeparturesProcessor& processor;
    EchoesAndDeparturesLook look;
    std::array<juce::Slider,6> knobs;
    juce::Image faceplate;
    std::array<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>,6> attachments;
    juce::ComboBox presets;
    juce::TooltipWindow tips {this, 700};
    void applyPreset(int);
    void timerCallback() override;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(EchoesAndDeparturesEditor)
};
