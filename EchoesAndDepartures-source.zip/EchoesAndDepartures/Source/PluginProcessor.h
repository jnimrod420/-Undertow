#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "EchoesAndDeparturesDSP.h"
#include "FactoryPresets.h"
class EchoesAndDeparturesProcessor final : public juce::AudioProcessor {
public:
    EchoesAndDeparturesProcessor();
    void prepareToPlay(double, int) override;
    void releaseResources() override {}
    void reset() override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "Echoes & Departures"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.25; }
    int getNumPrograms() override { return static_cast<int>(echoes::factoryPresets.size()); }
    int getCurrentProgram() override { return juce::jmax(0, selectedPreset.load()); }
    void setCurrentProgram(int) override;
    const juce::String getProgramName(int) override;
    int getSelectedPreset() const { return selectedPreset.load(); }
    bool isPresetModified() const;
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;
    juce::AudioProcessorValueTreeState state;
private:
    static juce::AudioProcessorValueTreeState::ParameterLayout layout();
    echoes::Parameters parameters() const;
    echoes::Engine engine;
    std::atomic<int> selectedPreset {-1};
    std::array<std::atomic<float>*, 6> values {};
    double activeSampleRate=48000;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(EchoesAndDeparturesProcessor)
};
