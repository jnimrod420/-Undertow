#pragma once
#include <array>
#include <vector>
#include <cmath>
#include <algorithm>
namespace palesignal {
constexpr double pi=3.141592653589793;
struct Settings {double drive=.5,tone=.5,mids=.5,rate=.3,depth=.5,blend=.5,output=-6;int clipping=0;bool dirt=true,chorus=true,vibrato=false,bypass=false;};
class Engine {
 double sr=48000,phase=0,smooth=.001;Settings cur{};bool ready=false;
 std::array<std::vector<double>,2> delay;size_t pos=0;
 std::array<double,2> hp{},previous{},aa{},low{},mid{},dark{};
 double bd=0,bc=0,bv=0,bb=0;
 double slew(double a,double b){return a+(b-a)*smooth;}
public:
 void prepare(double s){sr=s;smooth=1-std::exp(-1/(.02*sr));for(auto& d:delay)d.assign(size_t(sr*.06)+4,0);reset();}
 void reset(){for(auto& d:delay)std::fill(d.begin(),d.end(),0);pos=0;phase=0;hp={};previous={};aa={};low={};mid={};dark={};ready=false;}
 void process(float* const* c,int nc,int n,const Settings& s){
 if(!ready){cur=s;bd=s.dirt;bc=s.chorus;bv=s.vibrato;bb=s.bypass;ready=true;}
 for(int i=0;i<n;++i){
 cur.drive=slew(cur.drive,s.drive);cur.tone=slew(cur.tone,s.tone);cur.mids=slew(cur.mids,s.mids);cur.rate=slew(cur.rate,s.rate);cur.depth=slew(cur.depth,s.depth);cur.blend=slew(cur.blend,s.blend);cur.output=slew(cur.output,s.output);
 bd=slew(bd,s.dirt);bc=slew(bc,s.chorus);bv=slew(bv,s.vibrato);bb=slew(bb,s.bypass);
 double dry[2]={c[0][i],nc>1?c[1][i]:c[0][i]};
 phase+=(.06+cur.rate*cur.rate*7.94)/sr;phase-=std::floor(phase);
 for(int ch=0;ch<2;++ch){auto k=size_t(ch);double x=std::isfinite(dry[ch])?dry[ch]:0;
 hp[k]+=(1-std::exp(-2*pi*35/sr))*(x-hp[k]);double input=x-hp[k],z=0;
 // Four interpolated substeps with an ultrasonic low-pass before decimation.
 for(int os=1;os<=4;++os){double v=previous[k]+(input-previous[k])*os/4.;v*=2+cur.drive*78;
 double clipped=s.clipping==0?std::clamp(v,-.75,.75):s.clipping==1?std::tanh(v):std::clamp(v,-.45,.95);
 aa[k]+=(1-std::exp(-2*pi*std::min(18000.,sr*.38)/(sr*4)))*(clipped-aa[k]);z=aa[k];}previous[k]=input;
 low[k]+=(1-std::exp(-2*pi*350/sr))*(z-low[k]);mid[k]+=(1-std::exp(-2*pi*2200/sr))*(z-mid[k]);
 z=(low[k]*(1-cur.tone)*1.5+(z-mid[k])*cur.tone*1.5+(mid[k]-low[k])*(.15+cur.mids*1.8))*.65;
 dark[k]+=(1-std::exp(-2*pi*(3000+cur.tone*9000)/sr))*(z-dark[k]);x+=bd*(dark[k]-x);
 double lfo=std::sin(2*pi*(phase+(nc==2?ch*.17:0)));
 double samples=(.015+.008*cur.depth*lfo)*sr,p=double(pos)-samples;if(p<0)p+=double(delay[k].size());size_t a=size_t(p),b=(a+1)%delay[k].size();double wet=delay[k][a]+(delay[k][b]-delay[k][a])*(p-a);delay[k][pos]=x;
 double mix=cur.blend+(1-cur.blend)*bv;double y=x+bc*mix*(wet-x);double out=y*std::pow(10.,cur.output/20);out+=bb*(dry[ch]-out);
 if(ch<nc)c[ch][i]=float(std::isfinite(out)?std::clamp(out,-8.,8.):0);
 }pos=(pos+1)%delay[0].size();}
 }
};
}
