#include "Editor.h"


namespace {
const juce::Colour ink(0xff171716), ivory(0xffe5decd), black(0xff20201e);
juce::Font typewriter(float height) {
    return juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(),height,juce::Font::plain));
}
}
NightMassLook::NightMassLook() {
    setColour(juce::Slider::textBoxTextColourId,ink);
    setColour(juce::Slider::textBoxBackgroundColourId,juce::Colours::transparentBlack);
    setColour(juce::Slider::textBoxOutlineColourId,juce::Colours::transparentBlack);
    setColour(juce::ComboBox::backgroundColourId,black);
    setColour(juce::ComboBox::textColourId,ivory);
    setColour(juce::ComboBox::outlineColourId,ink);
    setColour(juce::PopupMenu::backgroundColourId,black);
    setColour(juce::PopupMenu::textColourId,ivory);
    setColour(juce::PopupMenu::highlightedBackgroundColourId,juce::Colour(0xff55534b));
    setColour(juce::PopupMenu::highlightedTextColourId,juce::Colours::white);
}
juce::Font NightMassLook::getComboBoxFont(juce::ComboBox&) { return typewriter(15.0f); }
juce::Label* NightMassLook::createSliderTextBox(juce::Slider& slider) {
    auto* label=juce::LookAndFeel_V4::createSliderTextBox(slider);
    label->setFont(typewriter(13.0f));
    return label;
}
void NightMassLook::drawComboBox(juce::Graphics& g,int w,int h,bool,int,int,int,int,juce::ComboBox&) {
    auto box=juce::Rectangle<float>(0,0,static_cast<float>(w),static_cast<float>(h));
    g.setColour(ink.withAlpha(.7f));g.fillRoundedRectangle(box,4);
    g.setColour(juce::Colour(0xffa39d91));g.drawRoundedRectangle(box.reduced(1),3,1);
    g.setGradientFill(juce::ColourGradient(juce::Colour(0xff2e2e2a),0,2,black,0,static_cast<float>(h),false));
    g.fillRoundedRectangle(box.reduced(3),2);
    g.setColour(ivory.withAlpha(.8f));juce::Path arrow;
    arrow.addTriangle(static_cast<float>(w-22),h*.43f,static_cast<float>(w-10),h*.43f,static_cast<float>(w-16),h*.64f);
    g.fillPath(arrow);
}
void NightMassLook::drawRotarySlider(juce::Graphics& g,int x,int y,int w,int h,float v,float start,float end,juce::Slider&) {
    auto box=juce::Rectangle<float>(static_cast<float>(x),static_cast<float>(y),static_cast<float>(w),static_cast<float>(h)).reduced(13);
    const float radius=juce::jmin(box.getWidth(),box.getHeight())*.5f;
    const auto c=box.getCentre();const float angle=start+v*(end-start);
    for(int i=0;i<=10;++i) {
        const float a=start+(end-start)*static_cast<float>(i)/10.0f;
        g.setColour(ink.withAlpha(i%3==0 ? .95f : .8f));
        g.drawLine(c.x+std::sin(a)*(radius+6),c.y-std::cos(a)*(radius+6),
                   c.x+std::sin(a)*(radius+12),c.y-std::cos(a)*(radius+12),1.6f);
    }
    for(int i=8;i>0;--i) {
        g.setColour(juce::Colours::black.withAlpha(.018f*static_cast<float>(9-i)));
        g.fillEllipse(c.x-radius-i*.45f,c.y-radius+3+i*.5f,radius*2+i*.9f,radius*2+i*.9f);
    }
    g.setColour(juce::Colour(0xff121311));g.fillEllipse(c.x-radius,c.y-radius,radius*2,radius*2);
    g.setColour(juce::Colour(0xff757367));g.drawEllipse(c.x-radius,c.y-radius,radius*2,radius*2,1.2f);
    for(int i=0;i<90;++i) {
        const float a=juce::MathConstants<float>::twoPi*static_cast<float>(i)/90.0f;
        g.setColour(i%2 ? juce::Colour(0xff55564f) : juce::Colour(0xff292b27));
        g.drawLine(c.x+std::sin(a)*(radius-1),c.y-std::cos(a)*(radius-1),
                   c.x+std::sin(a)*(radius-5),c.y-std::cos(a)*(radius-5),.8f);
    }
    const float inner=radius-6;
    g.setGradientFill(juce::ColourGradient(juce::Colour(0xff34362f),c.x-inner,c.y-inner,
                                        juce::Colour(0xff191c18),c.x+inner,c.y+inner,false));
    g.fillEllipse(c.x-inner,c.y-inner,inner*2,inner*2);
    g.setColour(juce::Colour(0xff7b796b).withAlpha(.6f));g.drawEllipse(c.x-inner,c.y-inner,inner*2,inner*2,.8f);
    // Fixed surface wear: deterministic and independent of knob value.
    for(int i=0;i<145;++i) {
        const float px=std::sin(i*127.1f)*inner*.9f,py=std::sin(i*311.7f)*inner*.9f;
        if(px*px+py*py<inner*inner*.87f) {
            g.setColour(juce::Colour(0xffaaa18a).withAlpha(i%4==0 ? .19f : .07f));
            g.drawLine(c.x+px,c.y+py,c.x+px+1.5f,c.y+py+.5f,.6f);
        }
    }
    g.setColour(ivory);g.drawLine(c.x+std::sin(angle)*radius*.20f,c.y-std::cos(angle)*radius*.20f,
                                c.x+std::sin(angle)*radius*.77f,c.y-std::cos(angle)*radius*.77f,3.0f);
}
namespace {
void stamp(juce::Graphics& g,const juce::String& text,juce::Rectangle<float> box,float height,juce::Colour colour=ink){
 g.setFont(typewriter(height));float width=g.getCurrentFont().getStringWidthFloat(text);float x=box.getCentreX()-width*.5f;
 for(int i=0;i<text.length();++i){auto c=text.substring(i,i+1);float w=g.getCurrentFont().getStringWidthFloat(c);juce::Graphics::ScopedSaveState save(g);g.addTransform(juce::AffineTransform::rotation(std::sin(float(i)*7.3f)*.06f,x+w*.5f,box.getCentreY()));g.setColour(colour.withAlpha(.77f+.2f*std::abs(std::sin(float(i)*12.1f))));g.drawText(c,juce::Rectangle<float>(x,box.getY()+std::sin(float(i)*3.7f)*1.8f,w+1,box.getHeight()),juce::Justification::centred,false);x+=w;}
}
void ghost(juce::Graphics& g,float x,float y,float p){
 const char* rows[]={"00001111110000","00111111111100","01111111111110","11111111111111","11100111100111","11100111100111","11111111111111","11110000001111","11111111111111","11111111111111","11111111111111","11101100110111","11001100110011"};
 g.setColour(ink);for(int r=0;r<13;++r)for(int c=0;c<14;++c)if(rows[r][c]=='1')g.fillRect(x+c*p,y+r*p,p,p);
 g.setColour(juce::Colour(0xffede6d6));g.fillRect(x+4*p,y+7*p,p,p*2);g.fillRect(x+9*p,y+7*p,p,p*2);
 g.setColour(juce::Colour(0xff792122));g.fillRect(x+4*p,y+9*p,p,p);g.fillRect(x+9*p,y+9*p,p,p*1.5f);
}
}
void NightMassEditor::addSlider(juce::Slider& k,const juce::String& id,bool db){addAndMakeVisible(k);k.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);k.setTextBoxStyle(juce::Slider::TextBoxBelow,false,80,20);k.setTextValueSuffix(db?" dB":id=="tempo"?" BPM":" %");k.setName(id);sliders.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(processor.state,id,k));k.setDoubleClickReturnValue(true,k.getValue());}
NightMassEditor::NightMassEditor(NightMassProcessor& p):AudioProcessorEditor(p),processor(p){
 setLookAndFeel(&look);setSize(1120,810);
 look.setColour(juce::TextButton::buttonColourId,black);look.setColour(juce::TextButton::textColourOffId,ivory);look.setColour(juce::ToggleButton::textColourId,ink);look.setColour(juce::ToggleButton::tickColourId,juce::Colour(0xff7c2426));
 for(int s=0;s<8;++s){auto i=size_t(s);for(int k=0;k<3;++k){auto& knob=knobs[size_t(s*3+k)];addSlider(knob,NightMassProcessor::key(s,("p"+juce::String(k)).toRawUTF8()));knob.setTooltip(nightmass::stageHelp[s]);}
  addAndMakeVisible(modes[i]);modes[i].setName(juce::String(nightmass::stageNames[s])+" mode");for(int k=0;k<3;++k)if(nightmass::modeNames[s][k])modes[i].addItem(nightmass::modeNames[s][k],k+1);combos.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(p.state,NightMassProcessor::key(s,"mode"),modes[i]));
  addAndMakeVisible(enabled[i]);enabled[i].setButtonText(nightmass::stageNames[s]);buttons.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(p.state,NightMassProcessor::key(s,"on"),enabled[i]));enabled[i].setTooltip("Enable or bypass "+juce::String(nightmass::stageNames[s]));
  addAndMakeVisible(left[i]);addAndMakeVisible(right[i]);left[i].setButtonText("<");right[i].setButtonText(">");left[i].setTooltip("Move effect earlier");right[i].setTooltip("Move effect later");left[i].onClick=[this,s]{auto o=processor.settings().order;auto it=std::find(o.begin(),o.end(),s);int pos=int(it-o.begin());processor.swapStages(pos,pos-1);timerCallback();};right[i].onClick=[this,s]{auto o=processor.settings().order;auto it=std::find(o.begin(),o.end(),s);int pos=int(it-o.begin());processor.swapStages(pos,pos+1);timerCallback();};
 }
 addAndMakeVisible(source);source.setName("Source mode");for(int i=0;i<5;++i)source.addItem(nightmass::sourceNames[i],i+1);combos.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(p.state,"source",source));source.setTooltip("Source voicing: input high-pass and drive tone; presets are grouped by source.");
 addAndMakeVisible(presets);presets.setName("Transmission preset");for(int n=0;n<50;++n){if(n%10==0)presets.addSectionHeading(nightmass::sourceNames[n/10]);presets.addItem(processor.getProgramName(n),n+1);}presets.onChange=[this]{int n=presets.getSelectedId();if(n>0){processor.setCurrentProgram(n-1);timerCallback();}};
 addAndMakeVisible(conjure);conjure.onClick=[this]{processor.generate();timerCallback();};conjure.setTooltip("Generate an original patch for the selected source.");
 addSlider(mix,"mix");addSlider(output,"output",true);addSlider(tempo,"tempo");tempo.setTooltip("Fallback tempo when the host does not supply BPM. Delay divisions: 1/16, 1/8, dotted 1/8, 1/4, dotted 1/4, 1/2.");
 addAndMakeVisible(bypass);bypass.setButtonText("BYPASS");addAndMakeVisible(sync);sync.setButtonText("HOST SYNC");buttons.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(p.state,"bypass",bypass));buttons.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(p.state,"sync",sync));timerCallback();startTimerHz(12);
}
NightMassEditor::~NightMassEditor(){stopTimer();setLookAndFeel(nullptr);}
void NightMassEditor::timerCallback(){auto o=processor.settings().order;if(o!=lastOrder){lastOrder=o;resized();repaint();}int n=processor.selectedPreset();auto name=n>=0?processor.getProgramName(n)+(processor.modified()?" *":""):"Unholy transmission";if(presets.getText()!=name){presets.setSelectedId(n>=0?n+1:0,juce::dontSendNotification);presets.setText(name,juce::dontSendNotification);}}
void NightMassEditor::resized(){source.setBounds(640,42,135,32);presets.setBounds(789,42,291,32);conjure.setBounds(935,92,145,30);
 auto order=processor.settings().order;for(int slot=0;slot<8;++slot){int s=order[size_t(slot)];auto i=size_t(s);int x=26+(slot%4)*274,y=174+(slot/4)*244;enabled[i].setBounds(x+12,y+10,165,26);left[i].setBounds(x+198,y+11,23,24);right[i].setBounds(x+225,y+11,23,24);left[i].setEnabled(slot>0);right[i].setEnabled(slot<7);modes[i].setBounds(x+14,y+45,230,28);for(int k=0;k<3;++k)knobs[size_t(s*3+k)].setBounds(x+4+k*85,y+94,84,114);}
 mix.setBounds(635,669,125,112);output.setBounds(773,669,125,112);tempo.setBounds(915,669,125,112);bypass.setBounds(275,715,125,32);sync.setBounds(445,715,145,32);
}
void NightMassEditor::paint(juce::Graphics& g){
 auto b=getLocalBounds().toFloat();g.setGradientFill(juce::ColourGradient(juce::Colour(0xffcac7bc),0,0,juce::Colour(0xff938f86),0,b.getHeight(),false));g.fillAll();
 juce::Random random(44417);for(int i=0;i<2600;++i){float x=random.nextFloat()*b.getWidth(),y=random.nextFloat()*b.getHeight();g.setColour((i%3?juce::Colours::black:juce::Colours::white).withAlpha(.015f+random.nextFloat()*.04f));g.drawLine(x,y,x+4+random.nextFloat()*35,y+.15f,.5f);}
 g.setColour(ink.withAlpha(.65f));g.drawRoundedRectangle(b.reduced(8),16,3);
 for(auto p:{juce::Point<float>{19,19}, {1101,19},{19,791},{1101,791}}){g.setColour(juce::Colour(0xff6a685f));g.fillEllipse(p.x-6,p.y-6,12,12);g.setColour(ink);g.drawLine(p.x-3,p.y+2,p.x+3,p.y-2,1.6f);}
 // Dried splatter stays outside the controls and text.
 juce::Random blood(13013);for(int i=0;i<65;++i){float x=i%2?1091+blood.nextFloat()*14:35+blood.nextFloat()*155,y=i%2?112+blood.nextFloat()*550:130+blood.nextFloat()*20;float r=1+blood.nextFloat()*4;g.setColour(juce::Colour(0xff6c1c22).withAlpha(.4f+blood.nextFloat()*.4f));g.fillEllipse(x,y,r,r*.75f);}g.setColour(juce::Colour(0xff71232a).withAlpha(.65f));g.drawLine(1089,580,1091,629,2);g.fillEllipse(1088,626,5,7);
 stamp(g,"NIGHT MASS",{153,33,440,59},49);stamp(g,"NOBODY BUT GHOSTS",{155,95,437,27},19);ghost(g,47,46,6);
 stamp(g,"SIGNAL RITES / 50 TRANSMISSIONS",{635,91,286,30},13);
 auto order=processor.settings().order;for(int slot=0;slot<8;++slot){int s=order[size_t(slot)],x=26+(slot%4)*274,y=174+(slot/4)*244;g.setColour(ink.withAlpha(.24f));g.drawRoundedRectangle(float(x),float(y),260,232,6,1.2f);g.setColour(juce::Colours::white.withAlpha(.08f));g.fillRoundedRectangle(float(x+1),float(y+1),258,230,6);for(int k=0;k<3;++k)stamp(g,k==2?(s==7?"Depth":"Blend"):nightmass::knobNames[s][k],{float(x+2+k*85),float(y+76),85,20},12);stamp(g,juce::String(slot+1)+" / "+juce::String(nightmass::stageNames[s])+" / SIGNAL RITE",{float(x+9),float(y+211),241,16},8);}
 stamp(g,"KEEP THE NIGHT INSIDE",{51,672,540,28},19);stamp(g,"Presence",{636,650,124,22},15);stamp(g,"Voice",{775,650,124,22},15);stamp(g,"Fallback",{916,650,124,22},15);ghost(g,63,714,4);stamp(g,"POST-PUNK / DARKWAVE / MULTI-FX",{217,765,392,22},12);
}
