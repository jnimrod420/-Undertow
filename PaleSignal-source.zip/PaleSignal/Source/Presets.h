#pragma once
#include "Engine.h"
namespace palesignal {
struct Preset {const char* name;Settings settings;};
inline const std::array<Preset,20> presets{{
 {"Flannel apparition",{.55,.48,.30,.23,.42,.42,-6,0,true,true,false,false}},
 {"Basement sun",{.68,.38,.58,.18,.3,.28,-6,1,true,true,false,false}},
 {"Warm static",{.22,.35,.65,.15,.25,.35,-4,1,true,true,false,false}},
 {"Porcelain riot",{.82,.72,.2,.32,.5,.4,-8,0,true,true,false,false}},
 {"Amber afterimage",{.25,.45,.55,.19,.6,.5,-2,1,false,true,false,false}},
 {"Offset haunting",{.45,.6,.45,.35,.48,.42,-6,0,true,true,false,false}},
 {"Rust communion",{.7,.3,.8,.1,.3,.2,-7,2,true,true,false,false}},
 {"Teenage poltergeist",{.9,.55,.6,.45,.65,.5,-8,0,true,true,false,false}},
 {"Broken television",{.75,.8,.1,.7,.8,.6,-9,2,true,true,false,false}},
 {"Saltwater cassette",{.3,.4,.5,.23,.65,1,-2,1,false,true,true,false}},
 {"Dead mall shimmer",{.3,.5,.5,.3,.5,.5,-2,0,false,true,false,false}},
 {"Summer went missing",{.35,.32,.75,.12,.42,.25,-5,1,true,true,false,false}},
 {"Buzzsaw at dawn",{1,.85,.3,.25,.4,.3,-9,0,true,false,false,false}},
 {"Velvet vandal",{.55,.25,.85,.15,.2,.2,-6,1,true,false,false,false}},
 {"Chemical lullaby",{.3,.5,.5,.48,.7,1,-3,0,false,true,true,false}},
 {"Wrong timeline",{.8,.55,.5,.65,.8,1,-8,2,true,true,true,false}},
 {"Ghost in the offset",{.35,.65,.65,.24,.32,.4,-5,1,true,true,false,false}},
 {"Sunburned tape",{.48,.35,.45,.32,.75,1,-6,2,true,true,true,false}},
 {"Last light upstairs",{.25,.45,.5,.08,.8,.5,-2,0,false,true,false,false}},
 {"Everything corroded",{1,.5,.75,.85,1,.65,-10,2,true,true,false,false}}
}};
}
