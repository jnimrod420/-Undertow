#pragma once
#include "Plugin.h"
class PaleSignalLook final:public juce::LookAndFeel_V4 {public:PaleSignalLook();juce::Font getComboBoxFont(juce::ComboBox&) override;juce::Label* createSliderTextBox(juce::Slider&) override;void drawComboBox(juce::Graphics&,int,int,bool,int,int,int,int,juce::ComboBox&) override;void drawRotarySlider(juce::Graphics&,int,int,int,int,float,float,float,juce::Slider&) override;};
class PaleSignalEditor final:public juce::AudioProcessorEditor,private juce::Timer {
public:PaleSignalEditor(PaleSignalProcessor&);~PaleSignalEditor() override{stopTimer();setLookAndFeel(nullptr);}void paint(juce::Graphics&) override;void resized() override;
private:PaleSignalProcessor& p;PaleSignalLook look;std::array<juce::Slider,7> knobs;juce::ComboBox presets,clipping;std::array<juce::ToggleButton,4> switches;
 std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sa;
 std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> ba;
 std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> ca;
 void timerCallback() override;
};
