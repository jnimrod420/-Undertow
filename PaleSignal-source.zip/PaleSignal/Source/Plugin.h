#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "Presets.h"
class PaleSignalProcessor final: public juce::AudioProcessor {
public:
 PaleSignalProcessor();
 void prepareToPlay(double s,int) override {engine.prepare(s);}
 void reset() override {engine.reset();}void releaseResources() override {}
 void processBlock(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
 bool isBusesLayoutSupported(const BusesLayout& l) const override {return l.getMainInputChannelSet()==l.getMainOutputChannelSet()&&(l.getMainOutputChannelSet()==juce::AudioChannelSet::mono()||l.getMainOutputChannelSet()==juce::AudioChannelSet::stereo());}
 const juce::String getName() const override{return "Pale Signal";}
 bool acceptsMidi() const override{return false;}bool producesMidi() const override{return false;}bool isMidiEffect() const override{return false;}
 double getTailLengthSeconds() const override{return .06;}
 bool hasEditor() const override{return true;}juce::AudioProcessorEditor* createEditor() override;
 juce::AudioProcessorParameter* getBypassParameter() const override{return state.getParameter("bypass");}
 int getNumPrograms() override{return 20;}int getCurrentProgram() override{return selected.load();}void setCurrentProgram(int) override;
 const juce::String getProgramName(int n) override{return n>=0&&n<20?palesignal::presets[size_t(n)].name:"";}
 void changeProgramName(int,const juce::String&) override{}
 void getStateInformation(juce::MemoryBlock&) override;void setStateInformation(const void*,int) override;
 palesignal::Settings settings() const;bool modified() const;
 juce::AudioProcessorValueTreeState state;
 static constexpr const char* ids[]={"drive","tone","mids","rate","depth","blend","output","clipping","dirt","chorus","vibrato","bypass"};
private:
 palesignal::Engine engine;std::atomic<int> selected{0};std::array<std::atomic<float>*,12> values{};
 static juce::AudioProcessorValueTreeState::ParameterLayout layout();
};
