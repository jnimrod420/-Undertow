#include "Editor.h"


namespace {
const juce::Colour ink(0xff171716), ivory(0xffeee1c2), black(0xff20201e);
juce::Font typewriter(float height) {
    return juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(),height,juce::Font::plain));
}
}
PaleSignalLook::PaleSignalLook() {
    setColour(juce::Slider::textBoxTextColourId,ink);
    setColour(juce::Slider::textBoxBackgroundColourId,juce::Colours::transparentBlack);
    setColour(juce::Slider::textBoxOutlineColourId,juce::Colours::transparentBlack);
    setColour(juce::ComboBox::backgroundColourId,black);
    setColour(juce::ComboBox::textColourId,ivory);
    setColour(juce::ComboBox::outlineColourId,ink);
    setColour(juce::PopupMenu::backgroundColourId,black);
    setColour(juce::PopupMenu::textColourId,ivory);
    setColour(juce::PopupMenu::highlightedBackgroundColourId,juce::Colour(0xff55534b));
    setColour(juce::PopupMenu::highlightedTextColourId,juce::Colours::white);
}
juce::Font PaleSignalLook::getComboBoxFont(juce::ComboBox&) { return typewriter(15.0f); }
juce::Label* PaleSignalLook::createSliderTextBox(juce::Slider& slider) {
    auto* label=juce::LookAndFeel_V4::createSliderTextBox(slider);
    label->setFont(typewriter(13.0f));
    return label;
}
void PaleSignalLook::drawComboBox(juce::Graphics& g,int w,int h,bool,int,int,int,int,juce::ComboBox&) {
    auto box=juce::Rectangle<float>(0,0,static_cast<float>(w),static_cast<float>(h));
    g.setColour(ink.withAlpha(.7f));g.fillRoundedRectangle(box,4);
    g.setColour(juce::Colour(0xffa39d91));g.drawRoundedRectangle(box.reduced(1),3,1);
    g.setGradientFill(juce::ColourGradient(juce::Colour(0xff2e2e2a),0,2,black,0,static_cast<float>(h),false));
    g.fillRoundedRectangle(box.reduced(3),2);
    g.setColour(ivory.withAlpha(.8f));juce::Path arrow;
    arrow.addTriangle(static_cast<float>(w-22),h*.43f,static_cast<float>(w-10),h*.43f,static_cast<float>(w-16),h*.64f);
    g.fillPath(arrow);
}
void PaleSignalLook::drawRotarySlider(juce::Graphics& g,int x,int y,int w,int h,float v,float start,float end,juce::Slider&) {
    auto box=juce::Rectangle<float>(static_cast<float>(x),static_cast<float>(y),static_cast<float>(w),static_cast<float>(h)).reduced(13);
    const float radius=juce::jmin(box.getWidth(),box.getHeight())*.5f;
    const auto c=box.getCentre();const float angle=start+v*(end-start);
    for(int i=0;i<=10;++i) {
        const float a=start+(end-start)*static_cast<float>(i)/10.0f;
        g.setColour(ink.withAlpha(i%3==0 ? .95f : .8f));
        g.drawLine(c.x+std::sin(a)*(radius+6),c.y-std::cos(a)*(radius+6),
                   c.x+std::sin(a)*(radius+12),c.y-std::cos(a)*(radius+12),1.6f);
    }
    for(int i=8;i>0;--i) {
        g.setColour(juce::Colours::black.withAlpha(.018f*static_cast<float>(9-i)));
        g.fillEllipse(c.x-radius-i*.45f,c.y-radius+3+i*.5f,radius*2+i*.9f,radius*2+i*.9f);
    }
    g.setColour(juce::Colour(0xff121311));g.fillEllipse(c.x-radius,c.y-radius,radius*2,radius*2);
    g.setColour(juce::Colour(0xff757367));g.drawEllipse(c.x-radius,c.y-radius,radius*2,radius*2,1.2f);
    for(int i=0;i<90;++i) {
        const float a=juce::MathConstants<float>::twoPi*static_cast<float>(i)/90.0f;
        g.setColour(i%2 ? juce::Colour(0xff55564f) : juce::Colour(0xff292b27));
        g.drawLine(c.x+std::sin(a)*(radius-1),c.y-std::cos(a)*(radius-1),
                   c.x+std::sin(a)*(radius-5),c.y-std::cos(a)*(radius-5),.8f);
    }
    const float inner=radius-6;
    g.setGradientFill(juce::ColourGradient(juce::Colour(0xff34362f),c.x-inner,c.y-inner,
                                        juce::Colour(0xff191c18),c.x+inner,c.y+inner,false));
    g.fillEllipse(c.x-inner,c.y-inner,inner*2,inner*2);
    g.setColour(juce::Colour(0xff7b796b).withAlpha(.6f));g.drawEllipse(c.x-inner,c.y-inner,inner*2,inner*2,.8f);
    // Fixed surface wear: deterministic and independent of knob value.
    for(int i=0;i<145;++i) {
        const float px=std::sin(i*127.1f)*inner*.9f,py=std::sin(i*311.7f)*inner*.9f;
        if(px*px+py*py<inner*inner*.87f) {
            g.setColour(juce::Colour(0xffaaa18a).withAlpha(i%4==0 ? .19f : .07f));
            g.drawLine(c.x+px,c.y+py,c.x+px+1.5f,c.y+py+.5f,.6f);
        }
    }
    g.setColour(ivory);g.drawLine(c.x+std::sin(angle)*radius*.20f,c.y-std::cos(angle)*radius*.20f,
                                c.x+std::sin(angle)*radius*.77f,c.y-std::cos(angle)*radius*.77f,3.0f);
}
namespace {
void stamp(juce::Graphics& g,const juce::String& text,juce::Rectangle<float> box,float height,juce::Colour colour=ink){
 g.setFont(typewriter(height));float width=g.getCurrentFont().getStringWidthFloat(text);float x=box.getCentreX()-width*.5f;
 for(int i=0;i<text.length();++i){auto c=text.substring(i,i+1);float w=g.getCurrentFont().getStringWidthFloat(c);juce::Graphics::ScopedSaveState save(g);g.addTransform(juce::AffineTransform::rotation(std::sin(float(i)*7.3f)*.06f,x+w*.5f,box.getCentreY()));g.setColour(colour.withAlpha(.77f+.2f*std::abs(std::sin(float(i)*12.1f))));g.drawText(c,juce::Rectangle<float>(x,box.getY()+std::sin(float(i)*3.7f)*1.8f,w+1,box.getHeight()),juce::Justification::centred,false);x+=w;}
}
void ghost(juce::Graphics& g,float x,float y,float p){
 const char* rows[]={"00001111110000","00111111111100","01111111111110","11111111111111","11100111100111","11100111100111","11111111111111","11110000001111","11111111111111","11111111111111","11111111111111","11101100110111","11001100110011"};
 g.setColour(ink);for(int r=0;r<13;++r)for(int c=0;c<14;++c)if(rows[r][c]=='1')g.fillRect(x+c*p,y+r*p,p,p);
 g.setColour(juce::Colour(0xffede6d6));g.fillRect(x+4*p,y+7*p,p,p*2);g.fillRect(x+9*p,y+7*p,p,p*2);
 g.setColour(juce::Colour(0xff792122));g.fillRect(x+4*p,y+9*p,p,p);g.fillRect(x+9*p,y+9*p,p,p*1.5f);
}
}
PaleSignalEditor::PaleSignalEditor(PaleSignalProcessor& proc):AudioProcessorEditor(proc),p(proc){
 setLookAndFeel(&look);setSize(760,570);
 look.setColour(juce::ToggleButton::textColourId,ink);look.setColour(juce::ToggleButton::tickColourId,juce::Colour(0xff755649));
 const char* tips[]={"Op-amp-style distortion gain","Dark-to-bright tone balance","Scooped to mid-forward body","Chorus LFO rate","Delay modulation depth","Dry / chorus balance; vibrato is fully wet","Output level in dB"};
 for(int i=0;i<7;++i){auto& k=knobs[size_t(i)];addAndMakeVisible(k);k.setName(PaleSignalProcessor::ids[i]);k.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);k.setTextBoxStyle(juce::Slider::TextBoxBelow,false,86,20);k.setTextValueSuffix(i==6?" dB":" %");k.setTooltip(tips[i]);sa.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.state,PaleSignalProcessor::ids[i],k));k.setDoubleClickReturnValue(true,k.getValue());}
 addAndMakeVisible(presets);presets.setName("Transmission preset");for(int i=0;i<20;++i)presets.addItem(p.getProgramName(i),i+1);presets.onChange=[this]{if(presets.getSelectedId()>0)p.setCurrentProgram(presets.getSelectedId()-1);};
 addAndMakeVisible(clipping);clipping.addItemList({"Silicon / hard","Soft / rounded","Asymmetric"},1);ca=std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(p.state,"clipping",clipping);
 const char* labels[]={"DISTORTION","CHORUS","VIBRATO","BYPASS"};for(int i=0;i<4;++i){addAndMakeVisible(switches[size_t(i)]);switches[size_t(i)].setButtonText(labels[i]);ba.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(p.state,PaleSignalProcessor::ids[i+8],switches[size_t(i)]));}
 timerCallback();startTimerHz(10);
}
void PaleSignalEditor::timerCallback(){auto name=p.getProgramName(p.getCurrentProgram())+(p.modified()?" *":"");if(presets.getText()!=name){presets.setSelectedId(p.getCurrentProgram()+1,juce::dontSendNotification);presets.setText(name,juce::dontSendNotification);}}
void PaleSignalEditor::resized(){presets.setBounds(414,49,308,34);for(int i=0;i<6;++i)knobs[size_t(i)].setBounds(45+(i%3)*136+(i/3)*310,189+(i/3)*135,115,125);
 // Two rows of three controls, all contained in their respective panel.
 for(int i=0;i<3;++i){knobs[size_t(i)].setBounds(43+i*108,189,106,130);knobs[size_t(i+3)].setBounds(407+i*108,189,106,130);}
 clipping.setBounds(54,342,294,32);switches[0].setBounds(99,404,170,32);switches[1].setBounds(434,404,145,32);switches[2].setBounds(590,342,126,32);switches[3].setBounds(54,490,130,32);knobs[6].setBounds(321,422,118,124);}
void PaleSignalEditor::paint(juce::Graphics& g){auto b=getLocalBounds().toFloat();g.setGradientFill(juce::ColourGradient(juce::Colour(0xffccc9bf),0,0,juce::Colour(0xff98968d),760,570,false));g.fillAll();
 juce::Random r(93191);for(int i=0;i<2800;++i){float x=r.nextFloat()*760,y=r.nextFloat()*570;g.setColour((i%3?juce::Colours::black:juce::Colours::white).withAlpha(.02f+r.nextFloat()*.065f));g.drawLine(x,y,x+r.nextFloat()*30,y+.5f,.7f);}
 g.setColour(ink.withAlpha(.65f));g.drawRoundedRectangle(b.reduced(9),12,2);
 for(int i=0;i<180;++i){float x=i%2?12+r.nextFloat()*8:739+r.nextFloat()*8,y=r.nextFloat()*550;g.setColour(ink.withAlpha(.2f));g.fillRect(x,y,1+r.nextFloat()*6,1+r.nextFloat()*8);}
 for(auto pt:{juce::Point<float>{23,23},{737,23},{23,547},{737,547}}){g.setColour(juce::Colour(0xff68685f));g.fillEllipse(pt.x-6,pt.y-6,12,12);g.setColour(ink);g.drawLine(pt.x-3,pt.y+2,pt.x+3,pt.y-2,1.5f);}
 stamp(g,"PALE SIGNAL",{111,39,290,49},34);stamp(g,"NOBODY BUT GHOSTS",{111,91,290,25},16);ghost(g,36,49,4.3f);
 stamp(g,"20 LOST TRANSMISSIONS",{413,93,309,25},13);
 for(int j=0;j<2;++j){int x=30+j*364;g.setColour(ink.withAlpha(.23f));g.drawRoundedRectangle(float(x),146,336,306,6,1.4f);stamp(g,j==0?"CORROSION":"AFTERIMAGE",{float(x),150,336,26},18);}
 const char* labels[]={"Bite","Ash","Body","Pulse","Wander","Veil"};for(int i=0;i<6;++i)stamp(g,labels[i],{float((i<3?43:407)+(i%3)*108),176,106,25},15);
 stamp(g,"CLIPPING VOICE",{54,316,294,24},12);stamp(g,"Voice",{322,408,118,25},14);stamp(g,"THE SIGNAL NEVER WASHES OUT",{451,492,262,35},12);
 // Faded flannel-like corner marks and paint scrapes stay clear of controls.
 g.setColour(ink.withAlpha(.1f));for(int i=0;i<6;++i){g.drawLine(44+i*7,126,82+i*7,126,2);g.drawLine(49+i*7,121,49+i*7,137,2);}g.setColour(juce::Colours::white.withAlpha(.28f));for(int i=0;i<32;++i){float x=20+r.nextFloat()*710;g.drawLine(x,462+r.nextFloat()*12,x+8+r.nextFloat()*20,464+r.nextFloat()*8,1);}
}
