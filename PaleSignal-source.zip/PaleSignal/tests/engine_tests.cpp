#include "../Source/Presets.h"
#include <iostream>
#include <stdexcept>
#include <set>
int main(){try {std::set<std::string> names;for(auto& p:palesignal::presets)names.insert(p.name);if(names.size()!=20)throw std::runtime_error("Preset names");
 for(double sr:{22050.,44100.,48000.,96000.,192000.})for(int channels:{1,2})for(auto& p:palesignal::presets){palesignal::Engine e;e.prepare(sr);std::array<float,257>a{},b{};float* ptr[]={a.data(),b.data()};double energy=0;
 for(int block=0;block<60;++block){for(int i=0;i<257;++i){a[size_t(i)]=float(.3*std::sin(2*palesignal::pi*220*(block*257+i)/sr));b[size_t(i)]=a[size_t(i)]*.7f;}e.process(ptr,channels,257,p.settings);for(int c=0;c<channels;++c)for(int i=0;i<257;++i){if(!std::isfinite(ptr[c][i])||std::abs(ptr[c][i])>8)throw std::runtime_error("Output unstable");energy+=ptr[c][i]*ptr[c][i];}}
 if(energy<.01)throw std::runtime_error("Silent preset");e.reset();auto bypass=p.settings;bypass.bypass=true;for(int i=0;i<257;++i)a[size_t(i)]=.123f;e.process(ptr,1,257,bypass);for(float x:a)if(std::abs(x-.123f)>.00001)throw std::runtime_error("Bypass mismatch");}
 std::cout<<"PASS: 20 unique audible presets; mono/stereo at five sample rates; bounded output, reset, exact bypass.\n";
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
