#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p "$HOME/Library/Audio/Plug-Ins/VST3" "$HOME/Library/Audio/Plug-Ins/Components"
ditto "Pale Signal.vst3" "$HOME/Library/Audio/Plug-Ins/VST3/Pale Signal.vst3"
ditto "Pale Signal.component" "$HOME/Library/Audio/Plug-Ins/Components/Pale Signal.component"
xattr -dr com.apple.quarantine "$HOME/Library/Audio/Plug-Ins/VST3/Pale Signal.vst3" "$HOME/Library/Audio/Plug-Ins/Components/Pale Signal.component" 2>/dev/null || true
printf 'Pale Signal installed. Restart your DAW and rescan plugins.\n'
