#ifndef PluginDir
#define PluginDir "..\..\build-palesignal\PaleSignal_artefacts\Release\VST3\Pale Signal.vst3"
#endif
[Setup]
AppId={{A3A6CD33-C329-478C-9459-CC0110AA0269}
AppName=Pale Signal
AppVersion=1.0.0
AppPublisher=Nobody But Ghosts
DefaultDirName={commoncf64}\VST3
DisableDirPage=yes
DisableProgramGroupPage=yes
UninstallFilesDir={autopf}\Nobody But Ghosts\Pale Signal
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=admin
OutputDir=..\..\dist-palesignal
OutputBaseFilename=PaleSignal-1.0.0-Windows-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
SetupLogging=yes
[Files]
Source: "{#PluginDir}\*"; DestDir: "{app}\Pale Signal.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
[UninstallDelete]
Type: dirifempty; Name: "{app}\Pale Signal.vst3"
[Messages]
WelcomeLabel2=This will install Pale Signal 1.0.0 by Nobody But Ghosts for 64-bit Windows VST3 hosts.%n%nClose REAPER or your audio host before continuing. After installation, reopen your host and rescan VST3 plugins.
FinishedLabel=Pale Signal has been installed. Open your audio host, rescan VST3 plugins, and select Pale Signal.
