# Pale Signal 1.0.0 — Nobody But Ghosts

Original audio effect inspired by the JPTR FX Bleach distortion + chorus concept. This is an independent approximation, not a measured circuit replica or affiliated product.

Worn silver, faded typewriter printing, scratches, chipped edges, black knobs and the pixel ghost. Corrosion controls: Bite (drive), Ash (tone), Body (mids), three clipping voices. Afterimage controls: Pulse (rate), Wander (depth), Veil (chorus blend); switch to fully wet vibrato. Independent distortion/chorus switches, output and host bypass.

20 factory presets. Mono/stereo, parameter automation and session recall.

## Native release build
JUCE 8.0.12 is fetched by CMake. Copy `.github/workflows/build-pale-signal.yml` into the repository workflow directory, place `PaleSignal-source.zip` at the repository root, then push to the `pale-signal` branch. The source ZIP must contain the PaleSignal folder.

GitHub Actions builds universal Intel/Apple Silicon macOS VST3 + AU and Windows x64 VST3, runs engine/GUI/session/host checks, creates an Inno Setup installer, checks installed file hashes and plugin loading, then tests uninstall. Release artifacts include Mac ZIP, Windows VST3 ZIP, Windows Setup.exe and an actual GUI snapshot.

Windows installer targets the standard Common Files/VST3 directory and provides an uninstaller. Mac package includes Install-Mac.command for per-user installation. Releases are unsigned/non-notarized unless signing credentials are supplied.

## Validation status
DSP tests passed locally: 20 unique audible presets, mono/stereo at 22050/44100/48000/96000/192000 Hz, finite bounded output, reset and exact initial bypass. Processor, editor and GUI test sources pass JUCE syntax checks. Native builds, GUI execution, plugin hosting and installer execution require the provided native workflow and have not yet run.
