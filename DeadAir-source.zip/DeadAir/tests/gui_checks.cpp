#include <juce_audio_utils/juce_audio_utils.h>
#include <iostream>
#include <stdexcept>
#include "../Source/FactoryPresets.h"
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter();
void require(bool ok,const char* message) { if(!ok) throw std::runtime_error(message); }
juce::AudioProcessorParameter* param(juce::AudioProcessor& p,const juce::String& name) {
    for(auto* v:p.getParameters()) if(v->getName(64)==name) return v;
    throw std::runtime_error("Missing parameter: "+name.toStdString());
}
int visibleKnobs(juce::AudioProcessorEditor& e) {
    int count=0;
    for(int i=0;i<e.getNumChildComponents();++i)
        if(auto* s=dynamic_cast<juce::Slider*>(e.getChildComponent(i))) {
            if(s->isVisible()) {
                require(s->getWidth()>100,"Knob too small");
                require(e.getLocalBounds().contains(s->getBounds()),"Knob outside GUI");
                ++count;
            }
        }
    return count;
}
juce::ComboBox* menu(juce::AudioProcessorEditor& e) {
    for(int i=0;i<e.getNumChildComponents();++i)
        if(auto* c=dynamic_cast<juce::ComboBox*>(e.getChildComponent(i)))
            if(c->getName()=="Transmission preset") return c;
    throw std::runtime_error("Transmission menu missing");
}
float raw(juce::AudioProcessor& p,const char* id) {
    for(auto* parameter:p.getParameters())
        if(auto* v=dynamic_cast<juce::RangedAudioParameter*>(parameter))
            if(v->getParameterID()==id) return v->convertFrom0to1(v->getValue());
    throw std::runtime_error("Missing ranged parameter");
}
void snapshot(juce::AudioProcessorEditor& e,const juce::String& path) {
    auto image=e.createComponentSnapshot(e.getLocalBounds(),true,1.f);
    require(image.isValid(),"Invalid GUI snapshot");
    auto file=juce::File::getCurrentWorkingDirectory().getChildFile(path);
    file.getParentDirectory().createDirectory();
    juce::FileOutputStream out(file); require(out.openedOk(),"Snapshot open failed");
    require(juce::PNGImageFormat().writeImageToStream(image,out),"Snapshot encoding failed");
}
int main(int argc,char** argv) {
    juce::ScopedJuceInitialiser_GUI init;
    try {
        std::unique_ptr<juce::AudioProcessor> p(createPluginFilter());
        require(p->getNumPrograms()==20,"Expected twenty factory programs");
        for(int n=0;n<20;++n) {
            p->setCurrentProgram(n);
            const auto& expected=deadair::factoryPresets[size_t(n)];
            for(size_t i=0;i<expected.values.size();++i)
                require(std::abs(raw(*p,deadair::parameterIds[i])-expected.values[i])<.05f,"Preset value wrong");
            std::unique_ptr<juce::AudioProcessorEditor> editor(p->createEditor());
            require(menu(*editor)->getNumItems()==20,"Preset menu entries missing");
            require(menu(*editor)->getText()==expected.name,"Preset label wrong");
            require(visibleKnobs(*editor)==(n>=15?1:10),"Preset mode wrong");
        }
        p->setCurrentProgram(0);
        auto* mode=param(*p,"Basic mode"); auto* freq=param(*p,"Oscillator Hz");
        freq->setValueNotifyingHost(.72f);
        std::unique_ptr<juce::AudioProcessorEditor> e(p->createEditor());
        require(visibleKnobs(*e)==10,"Full must show ten live knobs");
        require(menu(*e)->getText()=="Last broadcast *","Edited preset marker missing");
        if(argc>1) snapshot(*e,juce::String(argv[1])+"/DeadAir-Full.png");
        mode->setValueNotifyingHost(1);
        juce::MessageManager::getInstance()->runDispatchLoopUntil(150);
        require(visibleKnobs(*e)==1,"Mode switch must hide advanced knobs");
        if(argc>1) snapshot(*e,juce::String(argv[1])+"/DeadAir-Basic.png");
        juce::MemoryBlock saved; p->getStateInformation(saved);
        mode->setValueNotifyingHost(0); freq->setValueNotifyingHost(.05f);
        p->setStateInformation(saved.getData(),int(saved.getSize()));
        require(mode->getValue()>.5f,"Mode must persist in session");
        require(std::abs(freq->getValue()-.72f)<1e-5,"Advanced value must persist");
        e.reset(); e.reset(p->createEditor());
        require(visibleKnobs(*e)==1,"Reopened basic GUI must have one knob");
        mode->setValueNotifyingHost(0);
        juce::MessageManager::getInstance()->runDispatchLoopUntil(150);
        require(visibleKnobs(*e)==10,"Full controls must return");
        require(std::abs(freq->getValue()-.72f)<1e-5,"Switch must retain advanced value");
        menu(*e)->setSelectedId(7,juce::sendNotificationSync);
        require(p->getCurrentProgram()==6,"Menu did not select factory program");
        require(menu(*e)->getText()=="Tin man's prayer","Menu selection name wrong");
        juce::MemoryBlock presetState;p->getStateInformation(presetState);
        p->setCurrentProgram(15);
        p->setStateInformation(presetState.getData(),int(presetState.getSize()));
        e.reset();e.reset(p->createEditor());
        require(menu(*e)->getText()=="Tin man's prayer","Session lost preset identity");
        auto legacy=juce::AudioProcessor::getXmlFromBinary(presetState.getData(),int(presetState.getSize()));
        legacy->removeAttribute("factoryPreset");
        juce::MemoryBlock legacyState;juce::AudioProcessor::copyXmlToBinary(*legacy,legacyState);
        float before=raw(*p,"frequency");
        p->setStateInformation(legacyState.getData(),int(legacyState.getSize()));
        e.reset();e.reset(p->createEditor());
        require(menu(*e)->getText()=="Unknown transmission","Earlier session label wrong");
        require(std::abs(raw(*p,"frequency")-before)<1e-4,"Earlier session settings changed");
        std::cout<<"PASS: 20 presets, actual menu, correct modes/values, edited marker, preset/session recall and earlier sessions.\n";
    } catch(const std::exception& e) { std::cerr<<e.what()<<'\n';return 1; }
}
