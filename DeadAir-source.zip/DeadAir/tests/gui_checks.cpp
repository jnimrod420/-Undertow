#include <juce_audio_utils/juce_audio_utils.h>
#include <iostream>
#include <stdexcept>
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter();
void require(bool ok,const char* message) { if(!ok) throw std::runtime_error(message); }
juce::AudioProcessorParameter* param(juce::AudioProcessor& p,const juce::String& name) {
    for(auto* v:p.getParameters()) if(v->getName(64)==name) return v;
    throw std::runtime_error("Missing parameter: "+name.toStdString());
}
int visibleKnobs(juce::AudioProcessorEditor& e) {
    int count=0;
    for(int i=0;i<e.getNumChildComponents();++i)
        if(auto* s=dynamic_cast<juce::Slider*>(e.getChildComponent(i))) {
            if(s->isVisible()) {
                require(s->getWidth()>100,"Knob too small");
                require(e.getLocalBounds().contains(s->getBounds()),"Knob outside GUI");
                ++count;
            }
        }
    return count;
}
void snapshot(juce::AudioProcessorEditor& e,const juce::String& path) {
    auto image=e.createComponentSnapshot(e.getLocalBounds(),true,1.f);
    require(image.isValid(),"Invalid GUI snapshot");
    auto file=juce::File::getCurrentWorkingDirectory().getChildFile(path);
    file.getParentDirectory().createDirectory();
    juce::FileOutputStream out(file); require(out.openedOk(),"Snapshot open failed");
    require(juce::PNGImageFormat().writeImageToStream(image,out),"Snapshot encoding failed");
}
int main(int argc,char** argv) {
    juce::ScopedJuceInitialiser_GUI init;
    try {
        std::unique_ptr<juce::AudioProcessor> p(createPluginFilter());
        auto* mode=param(*p,"Basic mode"); auto* freq=param(*p,"Oscillator Hz");
        freq->setValueNotifyingHost(.72f);
        std::unique_ptr<juce::AudioProcessorEditor> e(p->createEditor());
        require(visibleKnobs(*e)==10,"Full must show ten live knobs");
        if(argc>1) snapshot(*e,juce::String(argv[1])+"/DeadAir-Full.png");
        mode->setValueNotifyingHost(1);
        juce::MessageManager::getInstance()->runDispatchLoopUntil(150);
        require(visibleKnobs(*e)==1,"Mode switch must hide advanced knobs");
        if(argc>1) snapshot(*e,juce::String(argv[1])+"/DeadAir-Basic.png");
        juce::MemoryBlock saved; p->getStateInformation(saved);
        mode->setValueNotifyingHost(0); freq->setValueNotifyingHost(.05f);
        p->setStateInformation(saved.getData(),int(saved.getSize()));
        require(mode->getValue()>.5f,"Mode must persist in session");
        require(std::abs(freq->getValue()-.72f)<1e-5,"Advanced value must persist");
        e.reset(); e.reset(p->createEditor());
        require(visibleKnobs(*e)==1,"Reopened basic GUI must have one knob");
        mode->setValueNotifyingHost(0);
        juce::MessageManager::getInstance()->runDispatchLoopUntil(150);
        require(visibleKnobs(*e)==10,"Full controls must return");
        require(std::abs(freq->getValue()-.72f)<1e-5,"Switch must retain advanced value");
        std::cout<<"PASS: real GUI, live mode switch, session recall, reopening, retained controls.\n";
    } catch(const std::exception& e) { std::cerr<<e.what()<<'\n';return 1; }
}
