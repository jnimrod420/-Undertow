#include <juce_audio_utils/juce_audio_utils.h>
#include <iostream>
#include <stdexcept>
void require(bool ok,const char* message) { if(!ok) throw std::runtime_error(message); }
int main(int argc,char** argv) {
    juce::ScopedJuceInitialiser_GUI init;
    try {
        require(argc>1,"VST3 path required");
        juce::AudioPluginFormatManager manager;
        manager.addFormat(new juce::VST3PluginFormat());
        juce::OwnedArray<juce::PluginDescription> types;
        manager.getFormat(0)->findAllTypesForFile(types,argv[1]);
        require(!types.isEmpty(),"VST3 scan failed");
        juce::String error;
        auto p=manager.createPluginInstance(*types[0],48000,256,error);
        require(p!=nullptr,"VST3 load failed");require(p->getParameters().size()>=16,"Parameter count");
        require(p->getNumPrograms()==20,"Loaded VST3 factory programs missing");
        p->setCurrentProgram(6);
        require(p->getProgramName(6)=="Tin man's prayer","Loaded VST3 preset name wrong");
        juce::MemoryBlock saved;p->getStateInformation(saved);
        p->setCurrentProgram(15);
        p->setStateInformation(saved.getData(),int(saved.getSize()));
        require(p->getCurrentProgram()==6,"Loaded VST3 lost preset identity");
        for(int count : {1,2}) {
            auto layout=p->getBusesLayout();
            layout.inputBuses.set(0,count==1?juce::AudioChannelSet::mono():juce::AudioChannelSet::stereo());
            layout.outputBuses.set(0,layout.inputBuses[0]);
            require(p->setBusesLayout(layout),"Mono/stereo layout failed");
            for(double sr : {44100.,48000.,96000.}) {
                p->setRateAndBufferSizeDetails(sr,256);p->prepareToPlay(sr,256);
                juce::AudioBuffer<float> b(count,256);juce::MidiBuffer midi;
                for(int n=0;n<50;++n) {
                    for(int ch=0;ch<count;++ch) for(int i=0;i<256;++i) b.setSample(ch,i,.25f*std::sin(float(n*256+i)*.04f));
                    p->processBlock(b,midi);
                    for(int ch=0;ch<count;++ch) for(int i=0;i<256;++i)
                        require(std::isfinite(b.getSample(ch,i))&&std::abs(b.getSample(ch,i))<=1,"Output not finite/bounded");
                }
                p->releaseResources();
            }
        }
        std::unique_ptr<juce::AudioProcessorEditor> editor(p->createEditorIfNeeded());
        require(editor!=nullptr,"VST3 editor failed");
        require(editor->createComponentSnapshot(editor->getLocalBounds()).isValid(),"VST3 GUI blank");
        std::cout<<"PASS: actual VST3 scan/load, parameters, mono/stereo, three sample rates and editor.\n";
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
