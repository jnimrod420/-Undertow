#include "../Source/Engine.h"
#include <iostream>
#include <stdexcept>
void check(bool condition,const char* message) { if(!condition) throw std::runtime_error(message); }
int main() {
  using namespace deadair;
  for(double sr : {22050.,44100.,48000.,96000.,192000.}) {
    Params p; Engine a,b; a.prepare(sr,p); b.prepare(sr,p);
    Params altered=p; altered.oscillator=1; altered.external=1; altered.frequency=5000;
    altered.depth=24; altered.rate=30; altered.bass=12; altered.mid=-12;
    altered.treble=12; altered.mix=0; altered.output=6; altered.mute=1;
    for(int i=0;i<100000;++i) {
      float x=float(.25*std::sin(2*pi*220*i/sr));
      auto y=a.tick(x,x,0,p), z=b.tick(x,x,1,altered);
      check(y==z,"Basic must ignore every full-mode control");
      check(std::isfinite(y[0])&&std::abs(y[0])<=1,"Bounded finite basic output");
    }
    p.basic=0; p.oscillator=1; p.depth=24; p.frequency=5000;
    p.damage=1; p.bass=p.mid=p.treble=12; p.output=6; a.prepare(sr,p);
    double energy=0;
    for(int i=0;i<100000;++i) {
      if(i%10000==0) { p.basic=1-p.basic; p.external=1-p.external; }
      auto y=a.tick(2.f*float(std::sin(i*.03)), -.2f, float(std::sin(i*.2)),p);
      check(std::isfinite(y[0])&&std::abs(y[0])<=1,"Finite bounded transition/extreme output");
      energy+=y[0]*y[0];
    }
    check(energy>1,"Processing must emit audio");
    p={}; p.basic=0; p.mix=0; a.prepare(sr,p);
    for(int i=0;i<1000;++i) {
      auto y=a.tick(.2f,-.1f,0,p);
      check(std::abs(y[0]-.2f)<1e-6 && std::abs(y[1]+.1f)<1e-6,"Dry mix preserves stereo");
    }
    p.mix=1; p.oscillator=0; a.prepare(sr,p);
    for(int i=0;i<100000;++i) a.tick(0,0,0,p);
    check(std::abs(a.tick(0,0,0,p)[0])<1e-6,"Silence settles; oscillator is not free-running output");
  }
  std::cout<<"PASS: five sample rates; basic isolation, dry stereo, silence, extremes, mode transitions.\n";
}
