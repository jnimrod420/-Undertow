#include "../Source/Engine.h"
#include "../Source/FactoryPresets.h"
#include <iostream>
#include <stdexcept>
void check(bool condition,const char* message) { if(!condition) throw std::runtime_error(message); }
int main() {
  using namespace deadair;
  constexpr std::array<float,16> minimum{0,0,0,20,0,.05f,0,0,0,0,-12,-12,-12,0,-24,0};
  constexpr std::array<float,16> maximum{1,1,1,5000,1,30,24,2,2,1,12,12,12,1,6,1};
  for(size_t n=0;n<factoryPresets.size();++n) {
    const auto& voice=factoryPresets[n];
    for(size_t i=0;i<voice.values.size();++i)
      check(voice.values[i]>=minimum[i]&&voice.values[i]<=maximum[i],"Preset value outside parameter range");
    for(size_t k=0;k<n;++k)
      check(std::string(voice.name)!=factoryPresets[k].name,"Preset names must be unique");
    check(voice.values[9]==0&&voice.values[15]==0,"Factory voices require no sidechain and are not muted");
    Params p;
    p.basic=voice.values[0];p.damage=voice.values[1];p.oscillator=voice.values[2];
    p.frequency=voice.values[3];p.blend=voice.values[4];p.rate=voice.values[5];
    p.depth=voice.values[6];p.wave=voice.values[7];p.lfoWave=voice.values[8];
    p.external=voice.values[9];p.bass=voice.values[10];p.mid=voice.values[11];
    p.treble=voice.values[12];p.mix=voice.values[13];p.output=voice.values[14];p.mute=voice.values[15];
    Engine engine;engine.prepare(48000,p);double energy=0;
    for(int i=0;i<48000;++i) {
      float x=float(.2*std::sin(2*pi*130*i/48000)+.04*std::sin(2*pi*1100*i/48000));
      auto y=engine.tick(x,x,0,p);
      check(std::isfinite(y[0])&&std::abs(y[0])<=1,"Preset output must be finite and bounded");
      energy+=y[0]*y[0];
    }
    check(energy>1,"Factory voice must produce audio");
  }
  for(double sr : {22050.,44100.,48000.,96000.,192000.}) {
    Params p; Engine a,b; a.prepare(sr,p); b.prepare(sr,p);
    Params altered=p; altered.oscillator=1; altered.external=1; altered.frequency=5000;
    altered.depth=24; altered.rate=30; altered.bass=12; altered.mid=-12;
    altered.treble=12; altered.mix=0; altered.output=6; altered.mute=1;
    for(int i=0;i<100000;++i) {
      float x=float(.25*std::sin(2*pi*220*i/sr));
      auto y=a.tick(x,x,0,p), z=b.tick(x,x,1,altered);
      check(y==z,"Basic must ignore every full-mode control");
      check(std::isfinite(y[0])&&std::abs(y[0])<=1,"Bounded finite basic output");
    }
    p.basic=0; p.oscillator=1; p.depth=24; p.frequency=5000;
    p.damage=1; p.bass=p.mid=p.treble=12; p.output=6; a.prepare(sr,p);
    double energy=0;
    for(int i=0;i<100000;++i) {
      if(i%10000==0) { p.basic=1-p.basic; p.external=1-p.external; }
      auto y=a.tick(2.f*float(std::sin(i*.03)), -.2f, float(std::sin(i*.2)),p);
      check(std::isfinite(y[0])&&std::abs(y[0])<=1,"Finite bounded transition/extreme output");
      energy+=y[0]*y[0];
    }
    check(energy>1,"Processing must emit audio");
    p={}; p.basic=0; p.mix=0; a.prepare(sr,p);
    for(int i=0;i<1000;++i) {
      auto y=a.tick(.2f,-.1f,0,p);
      check(std::abs(y[0]-.2f)<1e-6 && std::abs(y[1]+.1f)<1e-6,"Dry mix preserves stereo");
    }
    p.mix=1; p.oscillator=0; a.prepare(sr,p);
    for(int i=0;i<100000;++i) a.tick(0,0,0,p);
    check(std::abs(a.tick(0,0,0,p)[0])<1e-6,"Silence settles; oscillator is not free-running output");
  }
  std::cout<<"PASS: five sample rates; basic isolation, dry stereo, silence, extremes, mode transitions.\n";
}
