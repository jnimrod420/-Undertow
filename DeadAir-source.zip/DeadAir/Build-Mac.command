#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release '-DCMAKE_OSX_ARCHITECTURES=arm64;x86_64'
cmake --build build --config Release --parallel 4
ctest --test-dir build -C Release --output-on-failure
echo 'Built VST3: build/DeadAir_artefacts/Release/VST3/Dead Air.vst3'
