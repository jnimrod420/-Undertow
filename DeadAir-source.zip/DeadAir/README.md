# Dead Air — 0.2.0 prototype

An original vocal effect inspired by JMT's Noisy Mic-2, with a switch to a one-knob microphone distortion mode. This is a behavioral approximation, not a measured circuit model or an affiliated JMT product.

## Modes

**Full:** Damage (gain/distortion), internal oscillator on/off, carrier frequency and shape, Multiplex amount, LFO rate/depth/shape, bass/middle/treble EQ, wet mix, output, mute, and external carrier via a mono DAW sidechain.

**Basic:** One Damage knob. All full-mode controls are bypassed, including mix/output/mute. The knob maps distortion, bandwidth and output compensation together. Switching back restores the full-mode parameter values. Modes crossfade over approximately 15 ms to reduce clicks. Basic is an interpretation of the original mic's simple operation, not a claim that its hardware circuit is identical.

The oscillator is a carrier for the vocal signal, not a pitch tracker. Engage OSCILLATOR to use internal or external multiplex processing. External carrier requires the host to enable and route the sidechain input; selecting it with no input gives silence at 100% Multiplex. Sine, triangle and softened square waveforms are provided. LFO depth is in semitones.

The nonlinear stage uses four interpolation substeps, not full bandlimited oversampling. Some aliasing is expected with extreme modulation/distortion. No artificial hiss, bitcrusher, delay or reverb has been added.

## Build

Requires CMake 3.22+, Git, and a C++17 compiler. First configuration downloads JUCE 8.0.12. Review JUCE's licensing before distributing binaries.

Mac: install Xcode command-line tools and CMake, then run Build-Mac.command. Produces universal Apple Silicon/Intel VST3.

Windows: install Visual Studio 2022 with Desktop development with C++, plus CMake and Git, then run Build-Windows.bat. Produces x64 VST3.

Dead Air is stored as DeadAir-source.zip on the dead-air branch of jnimrod420/-Undertow. Unzip it to get the separate DeadAir project folder. Its root-level build-dead-air workflow builds both platforms and uploads binaries plus actual Full/Basic GUI screenshots after successful checks. Echoes & Departures files remain intact. The source folder contains a copy of the workflow for reference.

Copy the complete "Dead Air.vst3" bundle from build/DeadAir_artefacts/Release/VST3 into ~/Library/Audio/Plug-Ins/VST3 on Mac or C:\Program Files\Common Files\VST3 on Windows. Rescan Reaper. These instructions refer to binaries produced by the build; this source package is not an installer.

Offline DSP tests: compile tests/engine_tests.cpp with a C++17 compiler, or configure CMake with -DDEADAIR_ENGINE_ONLY=ON.

## References and validation

Manufacturer: https://www.jmtsynth.com/noisymic2

JMT documents a microphone/oscillator multiplex stage, distortion with treble/middle/bass, internal LFO and external input. The software routing follows that broad structure; component values and exact multiplex transfer behavior are unknown. Basic mode deliberately implements the requested one-knob workflow.

Validation results are provided in VALIDATION.txt. Mac/Windows binary generation, host loading, GUI behavior and session recall must be verified on their target platforms. The engine tests do not establish sonic equivalence to the hardware.

## GUI

The tarnished silver faceplate, uneven stamped lettering, dark knurled knobs and pixel ghost follow the approved Echoes & Departures plug-in design. Its original JUCE knob renderer is reused with an original procedural metal surface. All controls are native, interactive JUCE controls with DAW automation attachments. Basic mode displays one large Damage knob; Full mode restores ten knobs and carrier/LFO switches and menus. Voice is the output control; Blend is wet mix. Double-clicking a knob restores its default.

The GUI/session test checks the live mode switch, visible controls, persistence and editor reopening and can render actual screenshots. The host test scans and loads the compiled VST3 and checks mono/stereo processing at three sample rates.

Previews/ contains Full and Basic SVG/PNG design previews to review the layout. They are illustrative code-rendered designs, not screenshots of a compiled plugin. Actual JUCE screenshots will be produced by the GitHub workflow after uploading and a successful build.
