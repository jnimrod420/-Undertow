#pragma once
#include <JuceHeader.h>

namespace deadlook {
inline juce::Font stampedFont(float size) {
    return juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(),size,juce::Font::bold));
}
inline juce::Image metal(int width,int height) {
    juce::Image image(juce::Image::RGB,width,height,false);
    juce::Random random(0xDEADA17);
    for(int y=0;y<height;++y) for(int x=0;x<width;++x) {
        float edge=float(juce::jmin(x,y,width-1-x,height-1-y));
        float grain=float(random.nextInt(21)-10);
        float brush=std::sin(float(y)*1.7f)*4+std::sin(float(y)*.13f)*3;
        float cloud=std::sin(x*.013f+y*.006f)*7+std::cos(y*.019f-x*.002f)*5;
        float shade=juce::jmax(0.f,22-edge)*1.2f;
        int base=juce::jlimit(0,255,int(187+grain+brush+cloud-shade));
        image.setPixelAt(x,y,juce::Colour(juce::uint8(juce::jmin(255,base+9)),
            juce::uint8(base),juce::uint8(juce::jmax(0,base-12))));
    }
    juce::Graphics g(image);
    for(int i=0;i<11000;++i) {
        float x=random.nextFloat()*width,y=random.nextFloat()*height;
        float edge=juce::jmin(x,y,float(width)-x,float(height)-y);
        if(edge<30 || random.nextFloat()<.14f) {
            g.setColour(juce::Colour(0xff51402a).withAlpha(edge<30?.3f:.13f));
            g.drawLine(x,y,x+random.nextFloat()*7,y+random.nextFloat()*2,.7f);
        }
    }
    for(int i=0;i<2100;++i) {
        float x=random.nextFloat()*width,y=random.nextFloat()*height;
        float edge=juce::jmin(x,y,float(width)-x,float(height)-y);
        if(edge<35 || random.nextFloat()<.08f) {
            g.setColour(juce::Colour(0xff775332).withAlpha(.35f));
            g.fillEllipse(x,y,random.nextFloat()*3+1,random.nextFloat()*4+1);
        }
    }
    g.setColour(juce::Colour(0xffece5d6).withAlpha(.6f));g.drawRoundedRectangle(3,3,float(width-6),float(height-6),11,2);
    g.setColour(juce::Colour(0xff4b4031));g.drawRoundedRectangle(1,1,float(width-2),float(height-2),13,2);
    return image;
}
inline void stamp(juce::Graphics& g,const juce::String& text,juce::Rectangle<float> area,float size,int seed) {
    juce::Random random(seed);
    g.setFont(stampedFont(size));
    float charWidth=size*.61f;
    float x=area.getCentreX()-text.length()*charWidth*.5f;
    for(auto character:text) {
        float offset=(random.nextFloat()-.5f)*size*.2f;
        float angle=(random.nextFloat()-.5f)*.14f;
        juce::Graphics::ScopedSaveState save(g);
        g.addTransform(juce::AffineTransform::rotation(angle,x+charWidth*.5f,area.getCentreY()));
        g.setColour(juce::Colour(0xff191918).withAlpha(.65f+random.nextFloat()*.35f));
        g.drawText(juce::String::charToString(character),juce::Rectangle<float>(x,area.getY()+offset,charWidth+5,area.getHeight()),
            juce::Justification::centredLeft,false);
        x+=charWidth;
    }
}
inline void screw(juce::Graphics& g,float x,float y) {
    g.setColour(juce::Colours::black.withAlpha(.4f));g.fillEllipse(x-15,y-12,32,32);
    g.setGradientFill(juce::ColourGradient(juce::Colour(0xffdac8a8),x-12,y-12,juce::Colour(0xff28251e),x+12,y+12,false));
    g.fillEllipse(x-13,y-13,26,26);
    g.setColour(juce::Colour(0xff24231f));g.fillEllipse(x-8,y-8,16,16);
    g.setColour(juce::Colour(0xffc0b598));g.drawLine(x-5,y,x+5,y,2);g.drawLine(x,y-5,x,y+5,2);
}
inline void ghost(juce::Graphics& g,float x,float y,float scale) {
    const char* rows[]={
        "    XXXXX    ","  XX     XX  "," XX       XX "," X         X ",
        "X   X   X   X","X   X   X   X","X           X","X           X",
        "X           X","X           X","X X  X  X X X","XX XX XX XX X"};
    g.setColour(juce::Colour(0xff181917).withAlpha(.85f));
    for(int row=0;row<12;++row) for(int col=0;col<13;++col)
        if(rows[row][col]=='X') g.fillRect(x+col*scale,y+row*scale,scale,scale);
}
}
