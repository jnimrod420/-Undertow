#include "Look.h"
namespace {
const juce::Colour ink(0xff171716), ivory(0xffe5decd), black(0xff20201e);
juce::Font typewriter(float height) {
    return juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(),height,juce::Font::plain));
}
}
DeadAirLook::DeadAirLook() {
    setColour(juce::Slider::textBoxTextColourId,ink);
    setColour(juce::Slider::textBoxBackgroundColourId,juce::Colours::transparentBlack);
    setColour(juce::Slider::textBoxOutlineColourId,juce::Colours::transparentBlack);
    setColour(juce::ComboBox::backgroundColourId,black);
    setColour(juce::ComboBox::textColourId,ivory);
    setColour(juce::ComboBox::outlineColourId,ink);
    setColour(juce::PopupMenu::backgroundColourId,black);
    setColour(juce::PopupMenu::textColourId,ivory);
    setColour(juce::PopupMenu::highlightedBackgroundColourId,juce::Colour(0xff55534b));
    setColour(juce::PopupMenu::highlightedTextColourId,juce::Colours::white);
}
juce::Font DeadAirLook::getComboBoxFont(juce::ComboBox&) { return typewriter(15.0f); }
juce::Label* DeadAirLook::createSliderTextBox(juce::Slider& slider) {
    auto* label=juce::LookAndFeel_V4::createSliderTextBox(slider);
    label->setFont(typewriter(20.0f));
    return label;
}
void DeadAirLook::drawComboBox(juce::Graphics& g,int w,int h,bool,int,int,int,int,juce::ComboBox&) {
    auto box=juce::Rectangle<float>(0,0,static_cast<float>(w),static_cast<float>(h));
    g.setColour(ink.withAlpha(.7f));g.fillRoundedRectangle(box,4);
    g.setColour(juce::Colour(0xffa39d91));g.drawRoundedRectangle(box.reduced(1),3,1);
    g.setGradientFill(juce::ColourGradient(juce::Colour(0xff2e2e2a),0,2,black,0,static_cast<float>(h),false));
    g.fillRoundedRectangle(box.reduced(3),2);
    g.setColour(ivory.withAlpha(.8f));juce::Path arrow;
    arrow.addTriangle(static_cast<float>(w-22),h*.43f,static_cast<float>(w-10),h*.43f,static_cast<float>(w-16),h*.64f);
    g.fillPath(arrow);
}
void DeadAirLook::drawRotarySlider(juce::Graphics& g,int x,int y,int w,int h,float v,float start,float end,juce::Slider&) {
    auto box=juce::Rectangle<float>(static_cast<float>(x),static_cast<float>(y),static_cast<float>(w),static_cast<float>(h)).reduced(13);
    const float radius=juce::jmin(box.getWidth(),box.getHeight())*.5f;
    const auto c=box.getCentre();const float angle=start+v*(end-start);
    for(int i=0;i<=10;++i) {
        const float a=start+(end-start)*static_cast<float>(i)/10.0f;
        g.setColour(ink.withAlpha(i%3==0 ? .95f : .8f));
        g.drawLine(c.x+std::sin(a)*(radius+6),c.y-std::cos(a)*(radius+6),
                   c.x+std::sin(a)*(radius+12),c.y-std::cos(a)*(radius+12),1.6f);
    }
    for(int i=8;i>0;--i) {
        g.setColour(juce::Colours::black.withAlpha(.018f*static_cast<float>(9-i)));
        g.fillEllipse(c.x-radius-i*.45f,c.y-radius+3+i*.5f,radius*2+i*.9f,radius*2+i*.9f);
    }
    g.setColour(juce::Colour(0xff121311));g.fillEllipse(c.x-radius,c.y-radius,radius*2,radius*2);
    g.setColour(juce::Colour(0xff757367));g.drawEllipse(c.x-radius,c.y-radius,radius*2,radius*2,1.2f);
    for(int i=0;i<90;++i) {
        const float a=juce::MathConstants<float>::twoPi*static_cast<float>(i)/90.0f;
        g.setColour(i%2 ? juce::Colour(0xff55564f) : juce::Colour(0xff292b27));
        g.drawLine(c.x+std::sin(a)*(radius-1),c.y-std::cos(a)*(radius-1),
                   c.x+std::sin(a)*(radius-5),c.y-std::cos(a)*(radius-5),.8f);
    }
    const float inner=radius-6;
    g.setGradientFill(juce::ColourGradient(juce::Colour(0xff34362f),c.x-inner,c.y-inner,
                                        juce::Colour(0xff191c18),c.x+inner,c.y+inner,false));
    g.fillEllipse(c.x-inner,c.y-inner,inner*2,inner*2);
    g.setColour(juce::Colour(0xff7b796b).withAlpha(.6f));g.drawEllipse(c.x-inner,c.y-inner,inner*2,inner*2,.8f);
    // Fixed surface wear: deterministic and independent of knob value.
    for(int i=0;i<145;++i) {
        const float px=std::sin(i*127.1f)*inner*.9f,py=std::sin(i*311.7f)*inner*.9f;
        if(px*px+py*py<inner*inner*.87f) {
            g.setColour(juce::Colour(0xffaaa18a).withAlpha(i%4==0 ? .19f : .07f));
            g.drawLine(c.x+px,c.y+py,c.x+px+1.5f,c.y+py+.5f,.6f);
        }
    }
    g.setColour(ivory);g.drawLine(c.x+std::sin(angle)*radius*.20f,c.y-std::cos(angle)*radius*.20f,
                                c.x+std::sin(angle)*radius*.77f,c.y-std::cos(angle)*radius*.77f,3.0f);
}
