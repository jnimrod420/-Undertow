#pragma once
#include <JuceHeader.h>
class DeadAirLook final : public juce::LookAndFeel_V4 {
public:
    DeadAirLook();
    juce::Font getComboBoxFont(juce::ComboBox&) override;
    juce::Label* createSliderTextBox(juce::Slider&) override;
    void drawComboBox(juce::Graphics&,int,int,bool,int,int,int,int,juce::ComboBox&) override;
    void drawRotarySlider(juce::Graphics&,int,int,int,int,float,float,float,juce::Slider&) override;
};
