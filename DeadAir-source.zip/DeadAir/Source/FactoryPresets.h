#pragma once
#include <array>

namespace deadair {
inline constexpr std::array<const char*,16> parameterIds{
    "basic","damage","oscillator","frequency","blend","rate","depth",
    "wave","lfoWave","external","bass","mid","treble","mix","output","mute"};
struct Preset {
    const char* name;
    const char* description;
    std::array<float,16> values;
};
// Raw parameter values in parameterIds order. Every factory voice uses the
// internal signal path and unmuted output; no external routing is required.
inline constexpr std::array<Preset,20> factoryPresets{{
    {"Last broadcast","Mid-forward radio voice",
        {0,.55f,0,140,.4f,2,0,0,0,0,-10,7,-6,1,-4,0}},
    {"Teeth in the speaker","Driven megaphone vocal",
        {0,.75f,0,140,.4f,2,0,0,0,0,-12,10,-5,1,-6,0}},
    {"Rust on the tongue","Parallel gritty lead vocal",
        {0,.65f,0,140,.4f,2,0,0,0,0,0,3,-3,.65f,-4,0}},
    {"Velvet decay","Warm, dark vocal grit",
        {0,.28f,0,140,.4f,2,0,0,0,0,5,1,-10,.6f,-2,0}},
    {"Neon confessional","Bright edge with some clean voice",
        {0,.4f,0,140,.4f,2,0,0,0,0,-4,3,5,.55f,-4,0}},
    {"The caller","Classic robotic modulation",
        {0,.5f,1,145,.85f,2,0,0,0,0,-2,2,-2,.85f,-6,0}},
    {"Tin man's prayer","Metallic vocal texture",
        {0,.4f,1,520,.65f,.2f,1,0,0,0,-4,3,2,.75f,-6,0}},
    {"Basement choir","Low carrier growl; not a pitch shifter",
        {0,.7f,1,45,.8f,2,0,1,0,0,6,0,-8,.75f,-6,0}},
    {"Wrong frequency","High carrier, fractured robot",
        {0,.6f,1,900,.85f,2,0,0,0,0,-6,4,0,.8f,-7,0}},
    {"Voice from the void","Slowly moving low carrier",
        {0,.4f,1,85,.55f,.18f,5,1,0,0,3,1,-6,.6f,-5,0}},
    {"Do not answer","Rapidly unsettled transmission",
        {0,.55f,1,170,.55f,8,12,0,1,0,-3,3,-3,.75f,-6,0}},
    {"Possession protocol","Heavy growling square carrier",
        {0,.9f,1,90,.95f,.6f,3,2,0,0,4,1,-5,.9f,-8,0}},
    {"The walls are listening","Slow haunted carrier sweep",
        {0,.45f,1,350,.5f,.35f,7,0,1,0,-2,2,-4,.6f,-5,0}},
    {"Dead channel","Extreme noise-like vocal breakup",
        {0,.95f,1,1500,1,13,24,2,2,0,-8,5,2,.85f,-10,0}},
    {"Emergency override","Aggressive fast carrier changes",
        {0,.85f,1,280,.8f,9,16,2,2,0,-5,6,-2,.85f,-8,0}},
    {"The first crack","Basic: light microphone wear",
        {1,.12f,0,140,.4f,2,0,0,0,0,0,0,0,1,0,0}},
    {"Lost cassette","Basic: moderate lo-fi color",
        {1,.32f,0,140,.4f,2,0,0,0,0,0,0,0,1,0,0}},
    {"Broken intercom","Basic: narrow gritty microphone",
        {1,.55f,0,140,.4f,2,0,0,0,0,0,0,0,1,0,0}},
    {"Mouthful of static","Basic: heavy band-limited distortion",
        {1,.78f,0,140,.4f,2,0,0,0,0,0,0,0,1,0,0}},
    {"Dead air","Basic: maximum microphone damage",
        {1,1,0,140,.4f,2,0,0,0,0,0,0,0,1,0,0}}
}};
}
