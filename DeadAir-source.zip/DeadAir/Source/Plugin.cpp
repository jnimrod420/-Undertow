#include <JuceHeader.h>
#include "Engine.h"
#include "Look.h"
#include "Faceplate.h"
#include "FactoryPresets.h"

class DeadAirEditor;
class DeadAirProcessor final : public juce::AudioProcessor {
public:
    juce::AudioProcessorValueTreeState state;
    deadair::Engine engine;
    static juce::AudioProcessorValueTreeState::ParameterLayout layout() {
        juce::AudioProcessorValueTreeState::ParameterLayout l;
        auto number=[&](const char* id,const char* name,float min,float max,float def,float skew=1.f) {
            l.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{id,1},name,
                juce::NormalisableRange<float>{min,max,0.f,skew},def));
        };
        auto toggle=[&](const char* id,const char* name,bool def) {
            l.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{id,1},name,def));
        };
        toggle("basic","Basic mode",false); number("damage","Damage",0,1,.45f);
        toggle("oscillator","Oscillator on",false); toggle("external","External carrier",false);
        number("frequency","Oscillator Hz",20,5000,140,.3f);
        number("blend","Multiplex",0,1,.4f); number("rate","LFO Hz",.05f,30,2,.3f);
        number("depth","LFO semitones",0,24,0);
        number("bass","Bass dB",-12,12,0); number("mid","Middle dB",-12,12,0);
        number("treble","Treble dB",-12,12,0); number("mix","Wet mix",0,1,1);
        number("output","Output dB",-24,6,0); toggle("mute","Mute",false);
        l.add(std::make_unique<juce::AudioParameterChoice>(juce::ParameterID{"wave",1},
            "Oscillator shape",juce::StringArray{"Sine","Triangle","Soft square"},0));
        l.add(std::make_unique<juce::AudioParameterChoice>(juce::ParameterID{"lfoWave",1},
            "LFO shape",juce::StringArray{"Sine","Triangle","Soft square"},0));
        return l;
    }
    DeadAirProcessor():AudioProcessor(BusesProperties()
        .withInput("Input",juce::AudioChannelSet::stereo(),true)
        .withOutput("Output",juce::AudioChannelSet::stereo(),true)
        .withInput("External carrier",juce::AudioChannelSet::mono(),false)),
        state(*this,nullptr,"DeadAirState",layout()) {
        for(size_t i=0;i<values.size();++i)
            values[i]=state.getRawParameterValue(deadair::parameterIds[i]);
        setCurrentProgram(0);
    }
    deadair::Params parameters() const {
        deadair::Params p;
        p.basic=values[0]->load(); p.damage=values[1]->load(); p.oscillator=values[2]->load();
        p.frequency=values[3]->load(); p.blend=values[4]->load(); p.rate=values[5]->load();
        p.depth=values[6]->load(); p.wave=values[7]->load(); p.lfoWave=values[8]->load();
        p.external=values[9]->load(); p.bass=values[10]->load(); p.mid=values[11]->load();
        p.treble=values[12]->load(); p.mix=values[13]->load(); p.output=values[14]->load();
        p.mute=values[15]->load(); return p;
    }
    void prepareToPlay(double sr,int) override { engine.prepare(sr,parameters()); }
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout& b) const override {
        auto main=b.getMainInputChannelSet();
        return (main==juce::AudioChannelSet::mono()||main==juce::AudioChannelSet::stereo())
            &&main==b.getMainOutputChannelSet()
            &&(b.inputBuses.size()<2 || b.inputBuses[1].isDisabled()
               || b.inputBuses[1]==juce::AudioChannelSet::mono());
    }
    void processBlock(juce::AudioBuffer<float>& buffer,juce::MidiBuffer&) override {
        juce::ScopedNoDenormals noDenormals;
        auto main=getBusBuffer(buffer,false,0);
        auto p=parameters();
        const float* ext=nullptr;
        if(getBusCount(true)>1 && getBus(true,1)->isEnabled())
            ext=getBusBuffer(buffer,true,1).getReadPointer(0);
        auto* left=main.getWritePointer(0);
        auto* right=main.getNumChannels()>1?main.getWritePointer(1):nullptr;
        for(int i=0;i<main.getNumSamples();++i) {
            auto y=engine.tick(left[i],right?right[i]:left[i],ext?ext[i]:0,p);
            left[i]=y[0]; if(right) right[i]=y[1];
        }
    }
    const juce::String getName() const override { return "Dead Air"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return .5; }
    bool hasEditor() const override { return true; }
    juce::AudioProcessorEditor* createEditor() override;
    int getNumPrograms() override { return int(deadair::factoryPresets.size()); }
    int getCurrentProgram() override { return juce::jmax(0,selectedPreset.load()); }
    int getSelectedPreset() const { return selectedPreset.load(); }
    bool isPresetModified() const {
        int index=selectedPreset.load();
        if(index<0||index>=int(deadair::factoryPresets.size())) return false;
        const auto& expected=deadair::factoryPresets[size_t(index)].values;
        for(size_t i=0;i<expected.size();++i)
            if(std::abs(values[i]->load()-expected[i])>juce::jmax(.0001f,std::abs(expected[i])*.00001f))
                return true;
        return false;
    }
    void setCurrentProgram(int index) override {
        if(index<0||index>=getNumPrograms()) return;
        selectedPreset.store(index);
        const auto& preset=deadair::factoryPresets[size_t(index)];
        for(size_t i=0;i<preset.values.size();++i) {
            auto* parameter=state.getParameter(deadair::parameterIds[i]);
            parameter->beginChangeGesture();
            parameter->setValueNotifyingHost(parameter->convertTo0to1(preset.values[i]));
            parameter->endChangeGesture();
        }
        updateHostDisplay(juce::AudioProcessorListener::ChangeDetails().withProgramChanged(true));
    }
    const juce::String getProgramName(int index) override {
        return index>=0&&index<getNumPrograms()?deadair::factoryPresets[size_t(index)].name:juce::String{};
    }
    void changeProgramName(int,const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock& dest) override {
        auto xml=state.copyState().createXml();
        xml->setAttribute("factoryPreset",selectedPreset.load());
        copyXmlToBinary(*xml,dest);
    }
    void setStateInformation(const void* data,int size) override {
        if(auto xml=getXmlFromBinary(data,size)) {
            if(xml->hasTagName(state.state.getType())) {
                state.replaceState(juce::ValueTree::fromXml(*xml));
                int index=xml->getIntAttribute("factoryPreset",-1);
                selectedPreset.store(index>=0&&index<getNumPrograms()?index:-1);
                updateHostDisplay(juce::AudioProcessorListener::ChangeDetails().withProgramChanged(true));
            }
        }
    }
private:
    std::array<std::atomic<float>*,16> values{};
    std::atomic<int> selectedPreset{-1};
};

class DeadAirEditor final : public juce::AudioProcessorEditor,private juce::Timer {
    using SA=juce::AudioProcessorValueTreeState::SliderAttachment;
    using BA=juce::AudioProcessorValueTreeState::ButtonAttachment;
    using CA=juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    DeadAirProcessor& p;
    DeadAirLook theme;
    juce::Image faceplate=deadlook::metal(980,780);
    std::array<juce::Slider,10> knobs;
    std::array<juce::Label,10> labels;
    std::array<std::unique_ptr<SA>,10> attachments;
    juce::ToggleButton basic{"BASIC / ONE KNOB"},osc{"OSCILLATOR"},external{"EXTERNAL CARRIER"},mute{"MUTE"};
    juce::ComboBox wave,lfoWave,presets;
    std::unique_ptr<BA> basicA,oscA,externalA,muteA;
    std::unique_ptr<CA> waveA,lfoA;
    bool lastBasic=false;
public:
    explicit DeadAirEditor(DeadAirProcessor& processor):AudioProcessorEditor(processor),p(processor) {
        theme.setColour(juce::ToggleButton::textColourId,juce::Colour(0xff191918));
        theme.setColour(juce::ToggleButton::tickColourId,juce::Colour(0xff191918));
        theme.setColour(juce::ToggleButton::tickDisabledColourId,juce::Colour(0xff56534b));
        setLookAndFeel(&theme);
        const char* ids[]={"damage","frequency","blend","rate","depth","bass","mid","treble","mix","output"};
        const char* names[]={"DAMAGE","CARRIER / Hz","MULTIPLEX","LFO / Hz","LFO / semitones","BASS / dB",
            "MIDDLE / dB","TREBLE / dB","WET MIX","OUTPUT / dB"};
        for(size_t i=0;i<knobs.size();++i) {
            auto& k=knobs[i]; k.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            k.setTextBoxStyle(juce::Slider::TextBoxBelow,false,95,24);
            k.setNumDecimalPlacesToDisplay(i==1?1:2);
            k.setName(names[i]); k.setTitle(names[i]);
            k.setDoubleClickReturnValue(true,p.state.getParameter(ids[i])->convertFrom0to1(p.state.getParameter(ids[i])->getDefaultValue()));
            addAndMakeVisible(k); labels[i].setText(names[i],juce::dontSendNotification);
            labels[i].setJustificationType(juce::Justification::centred);
            labels[i].setColour(juce::Label::textColourId,juce::Colour(0xffc7bdab));
            addChildComponent(labels[i]);
            attachments[i]=std::make_unique<SA>(p.state,ids[i],k);
        }
        for(auto* b : {&basic,&osc,&external,&mute}) addAndMakeVisible(*b);
        basicA=std::make_unique<BA>(p.state,"basic",basic);
        oscA=std::make_unique<BA>(p.state,"oscillator",osc);
        externalA=std::make_unique<BA>(p.state,"external",external);
        muteA=std::make_unique<BA>(p.state,"mute",mute);
        wave.addItemList({"Sine","Triangle","Soft square"},1);
        lfoWave.addItemList({"Sine LFO","Triangle LFO","Soft square LFO"},1);
        addAndMakeVisible(wave); addAndMakeVisible(lfoWave);
        waveA=std::make_unique<CA>(p.state,"wave",wave);
        lfoA=std::make_unique<CA>(p.state,"lfoWave",lfoWave);
        presets.setName("Transmission preset");
        presets.setTextWhenNothingSelected("Unknown transmission");
        for(size_t i=0;i<deadair::factoryPresets.size();++i)
            presets.addItem(deadair::factoryPresets[i].name,int(i)+1);
        presets.onChange=[this] {
            int index=presets.getSelectedId()-1;
            if(index>=0) { p.setCurrentProgram(index);timerCallback(); }
        };
        addAndMakeVisible(presets);
        knobs[1].setTextValueSuffix(" Hz"); knobs[3].setTextValueSuffix(" Hz");
        for(int i : {5,6,7,9}) knobs[size_t(i)].setTextValueSuffix(" dB");
        knobs[4].setTextValueSuffix(" st");
        basic.setTooltip("Switch to one Damage knob. All advanced processing is bypassed; full settings are retained.");
        osc.setTooltip("Enable the internal or external carrier in the multiplex stage.");
        external.setTooltip("Use the mono DAW sidechain as carrier. Requires OSCILLATOR enabled and sidechain audio.");
        mute.setTooltip("Mute full-mode output. Basic mode bypasses this control.");
        setSize(980,780); startTimerHz(20); updateMode();timerCallback();
    }
    ~DeadAirEditor() override { setLookAndFeel(nullptr); }
    void updateMode() {
        lastBasic=p.state.getRawParameterValue("basic")->load()>=.5f;
        for(size_t i=1;i<knobs.size();++i) knobs[i].setVisible(!lastBasic);
        for(auto* b : {&osc,&external,&mute}) b->setVisible(!lastBasic);
        wave.setVisible(!lastBasic); lfoWave.setVisible(!lastBasic);
        resized(); repaint();
    }
    void timerCallback() override {
        if(lastBasic!=(p.state.getRawParameterValue("basic")->load()>=.5f)) updateMode();
        int index=p.getSelectedPreset();
        if(index<0) {
            if(presets.getSelectedId()!=0||presets.getText()!="Unknown transmission") {
                presets.setSelectedId(0,juce::dontSendNotification);
                presets.setText("Unknown transmission",juce::dontSendNotification);
            }
            presets.setTooltip("Custom or earlier session settings.");
        } else {
            juce::String name=p.getProgramName(index)+(p.isPresetModified()?" *":"");
            if(presets.getSelectedId()!=index+1||presets.getText()!=name) {
                presets.setSelectedId(index+1,juce::dontSendNotification);
                presets.setText(name,juce::dontSendNotification);
            }
            presets.setTooltip(juce::String(deadair::factoryPresets[size_t(index)].description)
                +". * means its controls have been edited.");
        }
    }
    void paint(juce::Graphics& g) override {
        g.drawImage(faceplate,getLocalBounds().toFloat());
        deadlook::screw(g,27,27);deadlook::screw(g,953,27);
        deadlook::screw(g,27,753);deadlook::screw(g,953,753);
        deadlook::stamp(g,"DEAD AIR",{55,28,510,60},49,104);
        deadlook::stamp(g,"NOBODY BUT GHOSTS",{70,85,460,26},18,52);
        deadlook::stamp(g,"TRANSMISSION",{633,23,292,23},13,24);
        g.setColour(juce::Colour(0xff282822).withAlpha(.65f));
        g.setFont(deadlook::stampedFont(13));
        g.drawText(lastBasic?"BASIC CIRCUIT / ONE KNOB":"FULL CIRCUIT / DISTORTION + MULTIPLEX + MODULATION",
            50,125,880,25,juce::Justification::centred);
        if(lastBasic) deadlook::stamp(g,"DAMAGE",{290,193,400,55},35,29);
        else {
            const char* names[]={"DAMAGE","CARRIER","MULTIPLEX","LFO RATE","LFO DEPTH","BASS","MIDDLE","TREBLE","BLEND","VOICE"};
            for(int i=0;i<10;++i) deadlook::stamp(g,names[i],
                {float(30+i%5*184),float(174+i/5*212),184,35},23,73+i*17);
            deadlook::stamp(g,"CARRIER SHAPE",{380,608,170,26},13,2);
            deadlook::stamp(g,"LFO SHAPE",{567,608,170,26},13,3);
        }
        deadlook::ghost(g,457,692,5);
        g.setColour(juce::Colour(0xff282822));g.setFont(deadlook::stampedFont(12));
        g.drawText(lastBasic?"A BROKEN TRANSMISSION":"VOCAL CORRUPTION / EXTERNAL CARRIER VIA SIDECHAIN",
            65,735,380,22,juce::Justification::centredLeft);
        g.drawText("MONO + STEREO",580,735,310,22,juce::Justification::centredRight);
    }
    void resized() override {
        presets.setBounds(633,50,292,38);
        basic.setBounds(690,94,220,29);
        if(lastBasic) {
            knobs[0].setBounds(320,263,340,320);
        } else {
            for(size_t i=0;i<knobs.size();++i) {
                int x=30+int(i%5)*184, y=212+int(i/5)*212;
                knobs[i].setBounds(x+9,y,166,164);
            }
            osc.setBounds(60,639,150,32); external.setBounds(210,639,170,32);
            wave.setBounds(395,639,155,32); lfoWave.setBounds(580,639,160,32);
            mute.setBounds(810,639,90,32);
        }
    }
};
juce::AudioProcessorEditor* DeadAirProcessor::createEditor() { return new DeadAirEditor(*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new DeadAirProcessor(); }
