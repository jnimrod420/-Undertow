#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace deadair {
constexpr double pi = 3.14159265358979323846;
struct Params {
    float basic=1, damage=.45f, oscillator=0, frequency=140, blend=.4f;
    float rate=2, depth=0, wave=0, lfoWave=0, external=0;
    float bass=0, mid=0, treble=0, mix=1, output=0, mute=0;
};
struct Channel {
    double low=0, high=0, dcIn=0, dcOut=0, previous=0;
    double eqLow=0, eqHigh=0;
    double process(double x, double drive, double hp, double lp, double sr,
                   double bass, double mid, double treble) {
        low += (1-std::exp(-2*pi*hp/sr))*(x-low);
        x -= low;
        double distorted=0;
        // Four substeps in the nonlinear stage reduce hard transition artifacts.
        // This is interpolation, not a complete oversampling/decimation filter.
        for (int k=1;k<=4;++k) {
            double v=previous+(x-previous)*k*.25;
            distorted += std::tanh(v*drive + .045)*.25;
        }
        previous=x;
        high += (1-std::exp(-2*pi*lp/sr))*(distorted-high);
        double y=high;
        eqLow += (1-std::exp(-2*pi*250/sr))*(y-eqLow);
        eqHigh += (1-std::exp(-2*pi*2500/sr))*(y-eqHigh);
        y=eqLow*std::pow(10.,bass/20.)
          +(eqHigh-eqLow)*std::pow(10.,mid/20.)
          +(y-eqHigh)*std::pow(10.,treble/20.);
        double out=y-dcIn+std::exp(-2*pi*20/sr)*dcOut;
        dcIn=y; dcOut=out;
        return out;
    }
};
class Engine {
    double sr=48000, phase=0, lfoPhase=0, fade=1, muteGain=1;
    double damage=.45, freq=140, blend=.4, depth=0, rate=2, mix=1, output=1;
    double bass=0, mid=0, treble=0, oscGain=0, extGain=0, smooth=.001;
    std::array<Channel,2> simple{}, full{};
    static double approach(double x,double target,double c) { return x+c*(target-x); }
    static double wave(double ph, int shape) {
        if(shape==1) return 1.-4.*std::abs(ph-.5);
        if(shape==2) return std::tanh(6.*std::sin(2*pi*ph));
        return std::sin(2*pi*ph);
    }
public:
    void prepare(double sampleRate, const Params& p = {}) {
        sr=std::max(8000.,sampleRate); smooth=1-std::exp(-1./(.015*sr));
        simple={}; full={}; phase=lfoPhase=0;
        fade=p.basic>=.5f?1:0; muteGain=p.mute>=.5f?0:1;
        damage=p.damage; freq=p.frequency; blend=p.blend; depth=p.depth; rate=p.rate;
        mix=p.mix; output=std::pow(10.,p.output/20.);
        bass=p.bass; mid=p.mid; treble=p.treble;
        oscGain=p.oscillator>=.5f?1:0; extGain=p.external>=.5f?1:0;
    }
    std::array<float,2> tick(float left,float right,float ext,const Params& p) {
        damage=approach(damage,std::clamp(double(p.damage),0.,1.),smooth);
        freq=approach(freq,std::clamp(double(p.frequency),20.,5000.),smooth);
        blend=approach(blend,std::clamp(double(p.blend),0.,1.),smooth);
        depth=approach(depth,std::clamp(double(p.depth),0.,24.),smooth);
        rate=approach(rate,std::clamp(double(p.rate),.05,30.),smooth);
        mix=approach(mix,std::clamp(double(p.mix),0.,1.),smooth);
        output=approach(output,std::pow(10.,std::clamp(double(p.output),-24.,6.)/20.),smooth);
        bass=approach(bass,std::clamp(double(p.bass),-12.,12.),smooth);
        mid=approach(mid,std::clamp(double(p.mid),-12.,12.),smooth);
        treble=approach(treble,std::clamp(double(p.treble),-12.,12.),smooth);
        fade=approach(fade,p.basic>=.5f?1:0,smooth);
        muteGain=approach(muteGain,p.mute>=.5f?0:1,smooth);
        oscGain=approach(oscGain,p.oscillator>=.5f?1:0,smooth);
        extGain=approach(extGain,p.external>=.5f?1:0,smooth);
        lfoPhase += rate/sr; lfoPhase -= std::floor(lfoPhase);
        double hz=std::clamp(freq*std::pow(2.,depth*wave(lfoPhase,int(p.lfoWave))/12.),20.,sr*.2);
        phase += hz/sr; phase -= std::floor(phase);
        double carrier=(1-extGain)*wave(phase,int(p.wave))+extGain*std::tanh(double(ext)*2);
        double amount=blend*oscGain;
        std::array<float,2> out{};
        std::array<double,2> in{left,right};
        for(int ch=0;ch<2;++ch) {
            double x=std::isfinite(in[ch])?in[ch]:0.;
            // Basic uses only damage: full settings cannot leak into this path.
            double a=simple[ch].process(x,1.+79.*damage*damage,
                100.+500.*damage,8000.-5500.*damage,sr,0,0,0)*(.9-.3*damage);
            double b=full[ch].process(x*(1.-amount)+x*carrier*amount,
                1.+99.*damage*damage,90.,std::min(12000.,sr*.4),sr,bass,mid,treble)*.65;
            b=(x*(1.-mix)+b*mix)*output*muteGain;
            out[ch]=float(std::clamp(a*fade+b*(1.-fade),-1.,1.));
        }
        return out;
    }
};
}
